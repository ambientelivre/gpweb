<?php 
/* 
Copyright (c) 2007-2011 The web2Project Development Team <w2p-developers@web2project.net>
Copyright (c) 2003-2007 The dotProject Development Team <core-developers@dotproject.net>
Copyright [2008] -  S�rgio Fernandes Reinert de Lima
Este arquivo � parte do programa gpweb
O gpweb � um software livre; voc� pode redistribu�-lo e/ou modific�-lo dentro dos termos da Licen�a P�blica Geral GNU como publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a.
Este programa � distribu�do na esperan�a que possa ser  �til, mas SEM NENHUMA GARANTIA; sem uma garantia impl�cita de ADEQUA��O a qualquer  MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU/GPL em portugu�s para maiores detalhes.
Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "licen�a GPL 2.odt", junto com este programa, se n�o, acesse o Portal do Software P�blico Brasileiro no endere�o www.softwarepublico.gov.br ou escreva para a Funda��o do Software Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/********************************************************************************************
		
gpweb\classes\ui.class.php		

Define a classe CAplic que ret�m as informa��es do usu�rio logado atrav�s das p�ginas																																							
																																												
********************************************************************************************/
if (!defined('BASE_DIR')) die('Voc� n�o deveria acessar este arquivo diretamente.');

if(!defined('UI_MSG_OK')) define('UI_MSG_OK', 1);
if(!defined('UI_MSG_ALERTA')) define('UI_MSG_ALERTA', 2);
if(!defined('UI_MSG_AVISO')) define('UI_MSG_AVISO', 3);
if(!defined('UI_MSG_ERRO')) define('UI_MSG_ERRO', 4);
$GLOBALS['traduzir'] = array();
if(!defined('UI_CAIXA_MASCARA')) define('UI_CAIXA_MASCARA', 0x0F);
if(!defined('UI_CAIXA_ALTA')) define('UI_CAIXA_ALTA', 1);
if(!defined('UI_CAIXA_BAIXA')) define('UI_CAIXA_BAIXA', 2);
if(!defined('UI_CAIXA_PRIMEIRA_ALTA')) define('UI_CAIXA_PRIMEIRA_ALTA', 3);
if(!defined('UI_MASCARA_SAIDA')) define('UI_MASCARA_SAIDA', 0xF0);
if(!defined('UI_SAIDA_HTML')) define('UI_SAIDA_HTML', 0);
if(!defined('UI_SAIDA_JS')) define('UI_SAIDA_JS', 0x10);
if(!defined('UI_SAIDA_CRUA')) define('UI_SAIDA_CRUA', 0x20);
require_once BASE_DIR.'/classes/permissoes.class.php';

class CAplic {
	var $estado = null;
	var $usuario_id = null;
  var $usuario_posto = null;
	var $usuario_nomeguerra = null;
	var $usuario_funcao = null;
	var $usuario_nome = null;
	var $usuario_nome_completo = null;
	var $usuario_cia = null;
	var $usuario_dept = null;
	var $usuario_grupo_dept = null;
	var $usuario_lista_dept = null;
	var $usuario_tem_lista_dept = null;
	var $usuario_email = null;
	var $usuario_email2 = null;
	var $usuario_rodape = null;
	var $usuario_admin = null;
	var $profissional = null;
	var $usuario_super_admin = null;
	var $usuario_acesso_email = null;
	var $usuario_pode_oculta = null;
	var $usuario_cm = null;
	var $conta_conjunta = null;
	var $chave_privada = null;
	var $chave_criada = null;
	var $chave_publica_id = null;
	var $senha_msg = null;
	var $usuario_ativo = null;
	var $usuario_pode_assinar = null;
	var $usuario_pode_protocolar = null;
	var $usuario_pode_outra_cia = null;
	var $usuario_pode_lateral = null;
	var $usuario_pode_superior = null;
	var $usuario_pode_todas_cias = null;
	var $usuario_pode_todos_depts = null;
	var $usuario_pode_dept_subordinado = null;
	var $usuario_pode_dept_lateral = null;
	var $usuario_pode_dept_superior = null;
	var $usuario_envia_cia = null;
	var $usuario_recebe_cia = null;
	var $usuario_inserir_demanda = null;
	var $usuario_analisa_demanda = null;
	var $usuario_analisa_viabilidade = null;
	var $usuario_cria_termo_abertura = null;
	var $usuario_aprovar_termo_abertura = null;
	var $usuario_cria_social = null;
	var $usuario_cria_acao = null;
	var $usuario_cria_familia = null;
	var $usuario_cria_comunidade = null;
	var $usuario_cria_comite = null;
	var $usuario_exporta_familia = null;
	var $usuario_importa_familia = null;
	var $usuario_gera_notebook = null;
	var $usuario_importa_notebook = null;
	var $usuario_pode_criar = null;
	var $usuario_pode_aprovar = null;
	var $usuario_pode_editar = null;
	var $usuario_pauta = null;
	var $usuario_prefs = null;
	var $dia_selecionado = null;
	var $usuario_localidade = null;
	var $usuario_linguagem = null;
	var $base_localidade = 'pt'; 
	var $msg = '';
	var $msgNo = '';
	var $redirecionarPadrao = '';
	var $cfg = null;
	var $versao_maior = null;
	var $versao_menor = null;
	var $versao_revisao = null;
	var $versao_string = null;
	var $versao_js_string = null;
	var $ultimo_acesso = 0;
	var $beta = null;
	var $ultimo_id_inserido = null;
	var $usuario_estilo = null;
	var $cor_msg_nao_lida = null;
	var $cor_msg_realce = null;
	var $celular = null;
	var $pdf_print = 0;
	var $gpweb_logo = '';
	var $gpweb_brasao = '';
	
	
	function CAplic() {
		global $config;
		$this->estado = array();
		$this->usuario_id = -1;
		$this->usuario_posto = '';
		$this->usuario_nomeguerra = '';
		$this->usuario_funcao = '';
		$this->usuario_nome = '';
		$this->usuario_nome_completo = '';
		$this->usuario_cia = null;
		$this->usuario_dept = null;
		$this->usuario_grupo_dept = null;
		$this->usuario_admin = 0;
		$this->profissional = file_exists(BASE_DIR.'/modulos/projetos/tarefa_cache.class_pro.php');
		$this->usuario_super_admin = 0;
		$this->usuario_acesso_email = 0;
		$this->usuario_pode_oculta = 0;
		$this->usuario_cm = 0;
		$this->chave_privada= '';
		$this->chave_criada= '';
		$this->chave_publica_id= null;
		$this->senha_msg= '';
		$this->conta_conjunta = 0;
		$this->usuario_ativo = 0;
		$this->usuario_pode_assinar = 0;
		$this->usuario_pode_protocolar = 0;
		$this->usuario_pode_criar = 0;
		$this->usuario_pode_aprovar = 0;
		$this->usuario_pode_editar = 0;
		$this->usuario_pauta = 0;
		$this->usuario_pode_outra_cia = 0;
		$this->usuario_pode_lateral = 0;
		$this->usuario_pode_superior = 0;
		$this->usuario_pode_todas_cias = 0;
		$this->usuario_pode_todos_depts = 0;
		$this->usuario_pode_dept_subordinado = 0;
		$this->usuario_pode_dept_lateral = 0;
		$this->usuario_pode_dept_superior = 0;
		$this->usuario_envia_cia = 0;
		$this->usuario_recebe_cia = 0;
		$this->usuario_inserir_demanda = 0;
		$this->usuario_analisa_demanda = 0;
		$this->usuario_analisa_viabilidade = 0;
		$this->usuario_cria_termo_abertura = 0;
		$this->usuario_aprovar_termo_abertura = 0;
		$this->usuario_cria_social = 0;
		$this->projeto_id = null;
		$this->redirecionarPadrao = '';
		$this->setUsuarioLocalidade($this->base_localidade);
		$this->usuario_prefs = array();
		$this->gpweb_logo = BASE_URL.'/'.(isset($config['logotipo']) ? $config['logotipo'] : 'estilo/rondon/imagens/organizacao/'.(isset($config['militar']) ? $config['militar'] : '10').'/gpweb_logo.png');
		$this->gpweb_brasao = BASE_URL.'/'.(isset($config['brasao']) ? $config['brasao'] : 'estilo/rondon/imagens/brasao.gif');
		}                        
	
	function &acl() {
		if (!isset($GLOBALS['acl'])) $GLOBALS['acl'] = new meu_acl;
		return $GLOBALS['acl'];
		}
		
	function getClasseSistema($nome = null) {
		if ($nome) return BASE_DIR.'/classes/'.$nome.'.class.php';
		}

	function getClasseBiblioteca($nome = null) {
		if ($nome) return BASE_DIR.'/lib/'.$nome.'.php';
		}


	function getClasseModulo($nome = null) {
		if ($nome) return BASE_DIR.'/modulos/'.$nome.'/'.$nome.'.class.php';
		}

	function getModuloAjax( $nome=null ) {
		if ($nome) return BASE_DIR.'/modulos/'.$nome.'/'.$nome.'.ajax.php';
		}

	function getVersao() {
		global $config;
		if (!isset($this->versao_maior)) {
			include_once BASE_DIR.'/incluir/versao.php';
			$this->versao_maior = $_versao_maior;
			$this->versao_menor = $_versao_menor;
			$this->_versao_revisao = $_versao_revisao;
			$this->beta = $beta;
			$this->versao_string = $this->versao_maior.'.'.$this->versao_menor.'.'.$this->_versao_revisao.($this->beta ? ' Beta '.$this->beta :'').'<br>'.$data_versao;
			$this->versao_js_string = $_versao_js_maior.'.'.$_versao_js_menor.'.'.$_versao_js_revisao;
			}
		return $this->versao_string;
		}
		
	function getVersaoJs() {
		global $config;
		if(!$this->versao_js_string) {
			include_once BASE_DIR.'/incluir/versao.php';
			$this->versao_js_string = $_versao_js_maior.'.'.$_versao_js_menor.'.'.$_versao_js_revisao;
			}
		return $this->versao_js_string;
		}

	function checarEstilo() {
		$estilo_ui = 'rondon';
		$this->setPref('ui_estilo', 'rondon');
		}

	function lerDirs($caminho) {
		$dirs = array();
		if (is_dir(BASE_DIR.'/'.$caminho)){
			$d = dir(BASE_DIR.'/'.$caminho);
			if ($d){
				while (false !== ($nome = $d->read())) {
					if (is_dir(BASE_DIR.'/'.$caminho.'/'.$nome) && $nome != '.' && $nome != '..' && $nome != 'CVS' && $nome != '.svn') $dirs[$nome] = $nome;
					}
				$d->close();
				}
			}	
		return $dirs;
		}

	function lerArquivos($caminho, $filtro = '.') {
		$arquivos = array();
		if (is_dir($caminho) && ($handle = opendir($caminho))) {
			while (false !== ($arquivo = readdir($handle))) {
				if ($arquivo != '.' && $arquivo != '..' && preg_match('/'.$filtro.'/', $arquivo)) $arquivos[$arquivo] = $arquivo;
				}
			closedir($handle);
			}
		return $arquivos;
		}

	function checarNomeArquivo($arquivo) {
		global $Aplic;
		$carc_ruins = ";/\\";
		$substituicao_ruim = '....'; 
		if (strpos(strtr($arquivo, $carc_ruins, $substituicao_ruim), '.') !== false) $Aplic->redirecionar('m=publico&a=acesso_negado');
		else return $arquivo;
		}

	function fazerNomeArquivoSeguro($arquivo) {
		$arquivo = str_replace('../', '', $arquivo);
		$arquivo = str_replace('..\\', '', $arquivo);
		return $arquivo;
		}

	function setUsuarioLocalidade($loc = '', $set = true) {
		global $localidade_tipo_caract;
		$IDIOMA = $this->carregarIdioma();
		if (!$loc) $loc = (isset($this->usuario_prefs['localidade']) && $this->usuario_prefs['localidade'] ? $this->usuario_prefs['localidade'] : config('idioma'));
		if (isset($IDIOMA[$loc])) $lingua = $IDIOMA[$loc];
		else {
			if (strlen($loc)> 2) {
				list($l, $c) = explode('_', $loc);
				$loc = $this->acharIdioma($l, $c);
				} 
			else {
				$loc = $this->acharIdioma($loc);
				}
			$lingua = $IDIOMA[$loc];
			}
		
		list($base_localidade, $texto_inglesa, $texto_nativa, $idioma_padrao, $lcs) = $lingua;
		if (!isset($lcs))	$lcs = (isset($localidade_tipo_caract)) ? $localidade_tipo_caract : 'utf-8';
		
		if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN') $usuario_linguagem = $idioma_padrao;
		else $usuario_linguagem = $loc.'.'.$lcs;
		
		if ($set) {
			$this->usuario_localidade = $base_localidade;
			$this->usuario_linguagem = $usuario_linguagem;
			$localidade_tipo_caract = $lcs;
			} 
		else return $usuario_linguagem;
		}

	function acharIdioma($idioma, $pais = false) {
		$IDIOMA = $this->carregarIdioma();
		$idioma = strtolower($idioma);
		if ($pais) {
			$pais = strtoupper($pais);
			$code = $idioma.'_'.$pais;
			if (isset($IDIOMA[$code])) return $code;
			}
		$primeira_entrada = null;
		foreach ($IDIOMA as $lingua => $info) {
			list($l, $c) = explode('_', $lingua);
			if ($l == $idioma) {
				if (!$primeira_entrada) $primeira_entrada = $lingua;
				if ($pais && $c == $pais) return $lingua;
				}
			}
		return $primeira_entrada;
		}

	function carregarIdioma() {
		$IDIOMA = array();
		$langs = $this->lerDirs('localidades');
		foreach ($langs as $lingua) if (file_exists(BASE_DIR.'/localidades/'.$lingua.'/idioma.php')) include BASE_DIR.'/localidades/'.$lingua.'/idioma.php';
		$_SESSION['IDIOMAS'] = &$IDIOMA;
		return $IDIOMA;
		}

	function _($str, $estados = 0) {
		if (is_array($str)) {
			$traduzido = array();
			foreach ($str as $s) $traduzido[] = $this->__($s, $estados);
			return implode(' ', $traduzido);
			} 
		else return $this->__($str, $estados);
		}

	function __($str, $estados = 0) {
		$str = trim($str);
		if (empty($str)) return '';
		$x = $GLOBALS['traduzir'][$str];
		$x = $str;
		if ($x)	$str = $x;
		
		switch ($estados & UI_CAIXA_MASCARA) {
			case UI_CAIXA_ALTA:
				$str = strtoupper($str);
				break;
			case UI_CAIXA_BAIXA:
				$str = strtolower($str);
				break;
			case UI_CAIXA_PRIMEIRA_ALTA:
				$str = ucwords($str);
				break;
			}
		global $localidade_tipo_caract;
		if (!$localidade_tipo_caract) $localidade_tipo_caract = 'iso-8859-1';
		switch ($estados & UI_MASCARA_SAIDA) {
			case UI_SAIDA_HTML:
				$str = htmlentities(stripslashes($str), ENT_COMPAT, $localidade_tipo_caract);
				break;
			case UI_SAIDA_JS:
				$str = addslashes(stripslashes($str)); 
				break;
			case UI_SAIDA_CRUA:
				$str = stripslashes($str);
				break;
			}
		return $str;
		}

	function salvarPosicao(){
		$qnt=0;
		$saida='';
		foreach($_REQUEST as $chave => $valor) {
			if (is_array($valor)){
				foreach($valor as $chave1 => $valor1) $saida.=($qnt++ ? '&' : '').$chave.'[]='.$valor1;
				}
			else $saida.=($qnt++ ? '&' : '').$chave.'='.$valor;
			}
		$this->estado['POSICAOSALVA']=$saida;
		}

	function resetarPosicao() {
		$this->estado['POSICAOSALVA'] = '';
		}

	function getPosicao() {
		if (isset($this->estado['POSICAOSALVA'])) return $this->estado['POSICAOSALVA'];
		else return '';
		
		}

	function setChavePrivada($chave) {
		return $this->chave_privada=$chave;
		}

	function setChaveCriada($chave) {
		return $this->chave_criada=$chave;
		}

	function setChavePublicaId($chave) {
		return $this->chave_publica_id=$chave;
		}

	function setSenhaMsg($senha) {
		return $this->senha_msg=$senha;
		}

	function redirecionar($toms = '', $hist = '', $caminho='') {
		if (!$toms) $toms = !empty($this->estado['POSICAOSALVA'.$hist]) ? $this->estado['POSICAOSALVA'.$hist] : $this->redirecionarPadrao;
		echo '<script>url_passar(0, \''.$toms.'\');</script>';
		exit();
		}
		
	function setMsg($msg, $msgNo = 0, $anexar = false) {
		$this->msg = $anexar ? $this->msg.' '.$msg : $msg;
		$this->msgNo = $msgNo;
		}
	
	function getMsg($reset = true) {
		$img = '';
		$classe = '';
		$msg = $this->msg;
		switch ($this->msgNo) {
			case UI_MSG_OK:
				$img = imagem('icones/ok.png');
				$classe = 'mensagem';
				break;
			case UI_MSG_ALERTA:
				$img = imagem('icones/alerta.png');
				$classe = 'mensagem';
				break;
			case UI_MSG_AVISO:
				$img = imagem('icones/informacao.gif');
				$classe = 'aviso';
				break;
			case UI_MSG_ERRO:
				$img = imagem('icones/cancelar.png');
				$classe = 'erro';
				break;
			default:
				$classe = 'mensagem';
				break;
			}
		if ($reset) {
			$this->msg = '';
			$this->msgNo = 0;
			}
		return $msg ? '<table cellspacing=0 cellpadding=0><tr><td>'.$img.'</td><td class="'.$classe.'">'.$msg.'</td></tr></table>' : '';
		}
	
	function setEstado($legenda, $valor = null) {
		//if (isset($valor)) $this->estado[$legenda] = $valor;
		$this->estado[$legenda] = $valor;
		}
	
	function getEstado($legenda, $valor_padrao = null) {
		if (array_key_exists($legenda, $this->estado))	return $this->estado[$legenda];
		elseif (isset($valor_padrao)) {
			$this->setEstado($legenda, $valor_padrao);
			return $valor_padrao;
			} 
		else return null;
		}
	
	function login($usuarioNome, $senha) {
		global $config;
		require_once BASE_DIR.'/classes/autenticacao.class.php';
		$metodo_autenticacao = config('metodo_autenticacao', 'sql');

		if ($_REQUEST['login'] != 'entrar' && $_REQUEST['login'] != $this->_('entrar', UI_SAIDA_CRUA) && $_REQUEST['login'] != $metodo_autenticacao) 	die('Voc� escolheu logar utilizando um m�todo n�o suportado ou desabilitado.');
		
		$usuarioNome = trim(db_escape($usuarioNome));
		$senha = trim($senha);

		$conectou=false;
		
		//para o programa gaucho usar o webservice em 1o lugar
		if ($config['militar']==11 && file_exists(BASE_DIR.'/modulos/sagri/autenticacao.class.php')) {
			require_once BASE_DIR.'/modulos/sagri/autenticacao.class.php';
			$auth = new PGQPAutenticador();
			$conectou=$auth->autenticar($usuarioNome, $senha);
			}
		
		
		if ($config['militar']!=11 || !$conectou)	{
			$auth = &getauth($metodo_autenticacao);
			$conectou=$auth->autenticar($usuarioNome, $senha);
			}
		

		if (!$conectou && $metodo_autenticacao=='sql') {
			//tentar LDAP
			$auth = &getauth('ldap');
			$conectou=$auth->autenticar($usuarioNome, $senha);
			}
			
		if (!$conectou && ($metodo_autenticacao=='ldap' || $metodo_autenticacao=='dgp')) {
			//tentar SQL
			$auth = &getauth('sql');
			$conectou=$auth->autenticar($usuarioNome, $senha);
			}	

		if (!$conectou) return false;
		
		$usuario_id = $auth->usuarioId($usuarioNome);
		$usuarioNome = $auth->usuarioNome; 
	
		$sql = new BDConsulta;
		
		$sql->adTabela('usuarios');
		$sql->esqUnir('contatos', 'contatos', 'contato_id = usuario_contato');
		$sql->adCampo('usuario_id, contato_posto AS usuario_posto, contato_nomeguerra AS usuario_nomeguerra, '.($config['militar'] < 10 ? 'concatenar_tres(contato_posto, \' \', contato_nomeguerra)' : 'contato_nomeguerra').' AS usuario_nome, contato_nomecompleto AS usuario_nome_completo, contato_funcao AS usuario_funcao, contato_cia AS usuario_cia, contato_dept AS usuario_dept, usuario_grupo_dept, contato_email AS usuario_email, contato_email2 AS usuario_email2, usuario_admin, usuario_acesso_email, usuario_rodape, usuario_pode_oculta, usuario_cm, usuario_ativo, usuario_pode_assinar, usuario_pode_protocolar, usuario_pode_outra_cia, usuario_pode_lateral, usuario_pode_superior, usuario_pode_todas_cias, usuario_envia_cia, usuario_recebe_cia, usuario_inserir_demanda, usuario_analisa_demanda, usuario_analisa_viabilidade, usuario_cria_termo_abertura, usuario_aprovar_termo_abertura, usuario_cria_social, usuario_cria_acao , usuario_cria_familia, usuario_cria_comunidade, usuario_cria_comite, usuario_exporta_familia, usuario_importa_familia, usuario_gera_notebook, usuario_importa_notebook, usuario_pode_criar, usuario_pode_aprovar, usuario_pode_editar, usuario_pauta');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$preparar = $sql->prepare();
		$sql->carregarObjeto($this);
		$sql->limpar();
		
		//Permiss�o de navegar nos departamento
		if($this->profissional){
			$this->usuario_pode_todos_depts = checarModulo('depts', 'acesso', $usuario_id, 'pode_todos');
			$this->usuario_pode_dept_subordinado = checarModulo('depts', 'acesso', $usuario_id, 'pode_subordinado');
			$this->usuario_pode_dept_lateral = checarModulo('depts', 'acesso', $usuario_id, 'pode_lateral');
			$this->usuario_pode_dept_superior = checarModulo('depts', 'acesso', $usuario_id, 'pode_superior');
			}
		else{
			$this->usuario_pode_todos_depts = 1;
			$this->usuario_pode_dept_subordinado = 1;
			$this->usuario_pode_dept_lateral = 1;
			$this->usuario_pode_dept_superior = 1;	
			}
		
		$sql->adTabela('usuario_dept');
		$sql->adCampo('usuario_departamento');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$sql->adOnde('usuario_departamento !='.(int)$usuario_id);
		$lista=$sql->listaVetorChave('usuario_departamento', 'usuario_departamento');
		$sql->limpar();
		
		if (count($lista)){
			$permitido=array();
			$this->usuario_tem_lista_dept=true;
			$sql->adTabela('usuarios');
			$sql->adCampo('usuario_contas');
			$sql->adOnde('usuario_id ='.(int)$usuario_id);
			$contas=$sql->resultado();
			$sql->limpar();
			$contas=explode(',',$contas);
			foreach($contas as $linha) if (isset($lista[$linha]) || $linha==$usuario_id) $permitido[]=$linha;
			$permitido=implode(',',$permitido);
			$this->usuario_lista_dept=$permitido;
			}
		else {
			$this->usuario_tem_lista_dept=false;
			$this->usuario_lista_dept='';
			}	


		$sql->adTabela('usuarios');
		$sql->adCampo('usuario_login2, usuario_senha2');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$outra_conta=$sql->Linha();
		$sql->limpar();
		
		if ($outra_conta['usuario_login2'] && $outra_conta['usuario_senha2']) $this->conta_conjunta=1;
		
		$sql->adTabela('preferencia_cor');
		$sql->adCampo('cor_msg_nao_lida, cor_msg_realce');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$cores=$sql->Linha();
		$sql->limpar();
		
		if (!$cores['cor_msg_nao_lida']){
			$sql->adTabela('preferencia_cor');
			$sql->adCampo('cor_msg_nao_lida, cor_msg_realce');
			$sql->adOnde('usuario_id IS NULL');
			$cores=$sql->Linha();
			$sql->limpar();
			}
		
		$this->cor_msg_nao_lida=($cores['cor_msg_nao_lida']? $cores['cor_msg_nao_lida'] :'fbfbda');
		$this->cor_msg_realce=($cores['cor_msg_realce']? $cores['cor_msg_realce'] :'ffffff');
		
		if ($_REQUEST['celular']) $this->celular=1;
		
		$this->carregarPrefs($this->usuario_id);
		$this->setUsuarioLocalidade();
		$this->checarEstilo();
		$this->usuario_super_admin=verificaAdministrador($this->usuario_id);
		if ($this->usuario_super_admin) $this->usuario_admin=1;
		return true;
		}
	

	function mudar_conta($usuario_id) {
		global $config;
		$this->registrarLogout($this->usuario_id);
		$sql = new BDConsulta;
		$sql->adTabela('usuarios');
		$sql->esqUnir('contatos', 'contatos', 'contato_id = usuario_contato');
		$sql->adCampo('usuario_id, contato_posto AS usuario_posto, contato_nomeguerra AS usuario_nomeguerra, '.($config['militar'] < 10 ? 'concatenar_tres(contato_posto, \' \', contato_nomeguerra)' : 'contato_nomeguerra').' AS usuario_nome, contato_nomecompleto AS usuario_nome_completo, contato_funcao AS usuario_funcao, contato_cia AS usuario_cia, contato_dept AS usuario_dept, usuario_grupo_dept, contato_email AS usuario_email, contato_email2 AS usuario_email2, usuario_admin, usuario_acesso_email, usuario_pode_oculta, usuario_cm, usuario_ativo, usuario_pode_assinar, usuario_pode_protocolar, usuario_pode_outra_cia, usuario_pode_lateral, usuario_pode_superior, usuario_pode_todas_cias, usuario_envia_cia, usuario_recebe_cia, usuario_inserir_demanda, usuario_analisa_demanda, usuario_analisa_viabilidade, usuario_cria_termo_abertura, usuario_aprovar_termo_abertura, usuario_cria_social, usuario_cria_acao , usuario_cria_familia, usuario_cria_comunidade, usuario_cria_comite, usuario_exporta_familia, usuario_importa_familia, usuario_gera_notebook, usuario_importa_notebook, usuario_pode_criar, usuario_pode_aprovar, usuario_pode_editar, usuario_pauta');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$preparar = $sql->prepare();
		$sql->carregarObjeto($this);
		$sql->limpar();
		
		$sql->adTabela('usuario_dept');
		$sql->adCampo('usuario_departamento');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$sql->adOnde('usuario_departamento !='.(int)$usuario_id);
		$lista=$sql->listaVetorChave('usuario_departamento', 'usuario_departamento');
		$sql->limpar();
		if (count($lista)){
			$permitido=array();
			$this->usuario_tem_lista_dept=true;
			$sql->adTabela('usuarios');
			$sql->adCampo('usuario_contas');
			$sql->adOnde('usuario_id ='.(int)$usuario_id);
			$contas=$sql->resultado();
			$sql->limpar();
			$contas=explode(',',$contas);
			foreach($contas as $linha) if (isset($lista[$linha]) || $linha==$usuario_id) $permitido[]=$linha;
			$permitido=implode(',',$permitido);
			$this->usuario_lista_dept=$permitido;
			}
		else {
			$this->usuario_tem_lista_dept=false;
			$this->usuario_lista_dept='';
			}	
		
		$sql->adTabela('usuarios');
		$sql->adCampo('usuario_login2, usuario_senha2');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$outra_conta=$sql->Linha();
		$sql->limpar();
		
		if ($outra_conta['usuario_login2'] && $outra_conta['usuario_senha2']) $this->conta_conjunta=1;
		
		$sql->adTabela('preferencia_cor');
		$sql->adCampo('cor_msg_nao_lida, cor_msg_realce');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$cores=$sql->Linha();
		$sql->limpar();
		
		if (!$cores['cor_msg_nao_lida']){
			$sql->adTabela('preferencia_cor');
			$sql->adCampo('cor_msg_nao_lida, cor_msg_realce');
			$sql->adOnde('usuario_id =0');
			$cores=$sql->Linha();
			$sql->limpar();
			}
		$this->cor_msg_nao_lida=($cores['cor_msg_nao_lida']? $cores['cor_msg_nao_lida'] :'fbfbda');
		$this->cor_msg_realce=($cores['cor_msg_realce']? $cores['cor_msg_realce'] :'ffffff');
		$this->carregarPrefs($this->usuario_id);
		$this->setUsuarioLocalidade();
		$this->checarEstilo();
		$this->usuario_super_admin=verificaAdministrador($this->usuario_id);
		if ($this->usuario_super_admin) $this->usuario_admin=1;
		return true;
		}
	
	
	function carregar_usuario($usuario_id) {
		global $config;
		$sql = new BDConsulta;
		$sql->adTabela('usuarios');
		$sql->esqUnir('contatos', 'contatos', 'contato_id = usuario_contato');
		$sql->adCampo('usuario_id, contato_posto AS usuario_posto, contato_nomeguerra AS usuario_nomeguerra, '.($config['militar'] < 10 ? 'concatenar_tres(contato_posto, \' \', contato_nomeguerra)' : 'contato_nomeguerra').' AS usuario_nome, contato_nomecompleto AS usuario_nome_completo, contato_funcao AS usuario_funcao, contato_cia AS usuario_cia, contato_dept AS usuario_dept, usuario_grupo_dept, contato_email AS usuario_email, contato_email2 AS usuario_email2, usuario_admin, usuario_acesso_email, usuario_pode_oculta, usuario_cm, usuario_ativo, usuario_pode_assinar, usuario_pode_protocolar, usuario_pode_outra_cia, usuario_pode_lateral, usuario_pode_superior, usuario_pode_todas_cias, usuario_envia_cia, usuario_recebe_cia, usuario_inserir_demanda, usuario_analisa_demanda, usuario_analisa_viabilidade, usuario_cria_termo_abertura, usuario_aprovar_termo_abertura, usuario_cria_social, usuario_cria_acao , usuario_cria_familia, usuario_cria_comunidade, usuario_cria_comite, usuario_exporta_familia, usuario_importa_familia, usuario_gera_notebook, usuario_importa_notebook, usuario_pode_criar, usuario_pode_aprovar, usuario_pode_editar, usuario_pauta');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$preparar = $sql->prepare();
		$sql->carregarObjeto($this);
		$sql->limpar();
		
		$sql->adTabela('usuario_dept');
		$sql->adCampo('usuario_departamento');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$sql->adOnde('usuario_departamento !='.(int)$usuario_id);
		$lista=$sql->listaVetorChave('usuario_departamento', 'usuario_departamento');
		$sql->limpar();
		if (count($lista)){
			$permitido=array();
			$this->usuario_tem_lista_dept=true;
			$sql->adTabela('usuarios');
			$sql->adCampo('usuario_contas');
			$sql->adOnde('usuario_id ='.(int)$usuario_id);
			$contas=$sql->resultado();
			$sql->limpar();
			$contas=explode(',',$contas);
			foreach($contas as $linha) if (isset($lista[$linha]) || $linha==$usuario_id) $permitido[]=$linha;
			$permitido=implode(',',$permitido);
			$this->usuario_lista_dept=$permitido;
			}
		else {
			$this->usuario_tem_lista_dept=false;
			$this->usuario_lista_dept='';
			}	
		
		$sql->adTabela('usuarios');
		$sql->adCampo('usuario_login2, usuario_senha2');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$outra_conta=$sql->Linha();
		$sql->limpar();
		
		if ($outra_conta['usuario_login2'] && $outra_conta['usuario_senha2']) $this->conta_conjunta=1;
		
		$sql->adTabela('preferencia_cor');
		$sql->adCampo('cor_msg_nao_lida, cor_msg_realce');
		$sql->adOnde('usuario_id ='.(int)$usuario_id);
		$cores=$sql->Linha();
		$sql->limpar();
		
		if (!$cores['cor_msg_nao_lida']){
			$sql->adTabela('preferencia_cor');
			$sql->adCampo('cor_msg_nao_lida, cor_msg_realce');
			$sql->adOnde('usuario_id =0');
			$cores=$sql->Linha();
			$sql->limpar();
			}
		
		
		$this->cor_msg_nao_lida=($cores['cor_msg_nao_lida']? $cores['cor_msg_nao_lida'] :'fbfbda');
		$this->cor_msg_realce=($cores['cor_msg_realce']? $cores['cor_msg_realce'] :'ffffff');
		
		$this->carregarPrefs($this->usuario_id);
		$this->checarEstilo();
		
		$this->usuario_super_admin=verificaAdministrador($this->usuario_id);
		if ($this->usuario_super_admin) $this->usuario_admin=1;
		return true;
		}
	
	function registrarLogin() {
		if ($this->usuario_id){
			$sql = new BDConsulta;
			$sql->adTabela('usuario_reg_acesso');
			$sql->adInserir('usuario_id', $this->usuario_id);
			$sql->adInserir('entrou', 'now()', false, true);
			$sql->adInserir('usuario_ip', $_SERVER['REMOTE_ADDR']);
			$sql->exec();
			$this->ultimo_id_inserido = db_insert_id('usuario_reg_acesso','usuario_reg_acesso_id');
			$sql->limpar();
			}
		}

	function registrarLogout($usuario_id) {
		$sql = new BDConsulta;
		$sql->adTabela('usuario_reg_acesso');
		$sql->adAtualizar('saiu', date('Y-m-d H:i:s'));
		$sql->adOnde('usuario_id = '.(int)$usuario_id.' AND saiu IS NULL');
		if ($usuario_id > 0) {
			$sql->exec();
			$sql->limpar();
			}
		}
	
	function atualizarUltimaAcao($ultimo_id_inserido) {
		if ($ultimo_id_inserido > 0) {
			$sql = new BDConsulta;
			$sql->adTabela('usuario_reg_acesso');
			$sql->adAtualizar('ultima_atividade', date('Y-m-d H:i:s'));
			$sql->adOnde('usuario_reg_acesso_id = '.$ultimo_id_inserido);
			$sql->exec();
			$sql->limpar();
			}
		}
	
	function logout() {
		}
	
	function fazerLogin() {
		return ($this->usuario_id < 0) ? true : false;
		}
	
	function getPref($nome) {
		return (isset($this->usuario_prefs[$nome]) ? $this->usuario_prefs[$nome] : null);
		}
	
	function setPref($nome, $val) {
		$this->usuario_prefs[$nome] = $val;
		}
	
	function carregarPrefs($uid = 0) {
		$sql = new BDConsulta;
		$sql->adTabela('preferencia');
		$sql->adCampo('preferencia.*');
		if ($uid) $sql->adOnde('usuario = '.(int)$uid);
		else $sql->adOnde('usuario IS NULL OR usuario=0');
		$prefs = $sql->Linha();
		$sql->limpar();	
		if (!count($prefs)){
			$sql->adTabela('preferencia');
			$sql->adCampo('preferencia.*');
			$sql->adOnde('usuario IS NULL OR usuario=0');
			$prefs = $sql->Linha();
			$sql->limpar();	
			}
		$this->usuario_prefs = array_merge($this->usuario_prefs, (array)$prefs);
		}
	
	function getModulosInstalados() {
		$sql = new BDConsulta;
		$sql->adTabela('modulos');
		$sql->adCampo('mod_diretorio, mod_ui_nome');
		$sql->adOrdem('mod_diretorio');
		return ($sql->ListaChave());
		}
	
	function getModulosAtivos() {
		$sql = new BDConsulta;
		$sql->adTabela('modulos');
		$sql->adCampo('mod_diretorio, mod_ui_nome');
		$sql->adOnde('mod_ativo = 1');
		$sql->adOrdem('mod_diretorio');
		return ($sql->ListaChave());
		}
	
	function getMenuModulos() {
		$sql = new BDConsulta;
		$sql->adTabela('modulos');
		$sql->adCampo('mod_diretorio, mod_ui_nome, mod_ui_icone, mod_texto_botao');
		$sql->adOnde('mod_ativo > 0 AND mod_ui_ativo > 0 AND mod_diretorio !=\'publico\'');
		$sql->adOnde('mod_tipo != \'utilitario\'');
		$sql->adOrdem('mod_ui_ordem');
		return ($sql->Lista());
		}

	function ModuloAtivo($modulo) {
		$sql = new BDConsulta;
		$sql->adTabela('modulos');
		$sql->adCampo('mod_ativo');
		$sql->adOnde('mod_diretorio = \''.$modulo.'\'');
		$resultado = $sql->Resultado();
		$sql->limpar();
		return $resultado;
		}
	
	function carregarCabecalhoJS() {
		global $m, $a, $jquery;
		include BASE_DIR.'/js/base.php';
		
		$raiz = BASE_DIR;
		if (substr($raiz, -1) != '/') $raiz .= '/';
		$base = BASE_URL;
		if (substr($base, -1) != '/') $base .= '/';
		if ($jquery) echo '<script type="text/javascript" src="'.BASE_URL.'/lib/jquery/jquery-1.8.3.min.js"></script>';
		echo '<script type="text/javascript" src="'.$base.'lib/mootools/mootools.js"></script>';

		
		if (!isset($m))	return;
		$this->getModuloJS($m, $a, true);
		}

	function getModuloJS($modulo, $arquivo = null, $carregar_todos = false) {
		$raiz = BASE_DIR;
		if (substr($raiz, -1) != '/') $raiz .= '/';
		$base = BASE_URL;
		if (substr($base, -1) != '/')	$base .= '/';
		if ($carregar_todos || !$arquivo) {
			if (file_exists($raiz.'modulos/'.$modulo.'/'.$modulo.'.modulo.js')) echo '<script type="text/javascript" src="'.$base.'modulos/'.$modulo.'/'.$modulo.'.modulo.js"></script>';
			}
		if (isset($arquivo) && file_exists($raiz.'modulos/'.$modulo.'/'.$arquivo.'.js')) echo '<script type="text/javascript" src="'.$base.'modulos/'.$modulo.'/'.$arquivo.'.js"></script>';
		}

	function carregarRodapeJS() {
		echo '<script type="text/javascript">window.addEvent(\'domready\', function(){var as = []; $$(\'span\').each(function(span){if (span.getAttribute(\'title\')) as.push(span);});new Tips(as), {	}});</script>';
		}

	function carregarCalendario() {
		global $Aplic;
		echo '<!DOCTYPE html PUBLIC
          "-//W3C//DTD XHTML 1.0 Transitional//EN"
          "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
		echo '<script type="text/javascript" src="'.BASE_URL.'/js/calendario.js"></script>';
		echo '<script type="text/javascript" src="'.BASE_URL.'/lib/calendario/src/js/jscal2.js"></script>';
		echo '<script type="text/javascript" src="'.BASE_URL.'/lib/calendario/src/js/pt.js"></script>';
		include BASE_DIR.'/js/calendario.php';
		}

	function carregarCalendarJS() {
		global $Aplic;
		echo '<style type="text/css">@import url('.BASE_URL.'/lib/jscalendar/skins/aqua/theme.css);</style>';
		echo '<script type="text/javascript" src="'.BASE_URL.'/js/calendar.js"></script>';
		echo '<script type="text/javascript" src="'.BASE_URL.'/lib/jscalendar/calendar.js"></script>';
		if (file_exists (BASE_DIR.'/lib/jscalendar/lang/calendar-pt.js')) echo '<script type="text/javascript" src="'.BASE_URL.'/lib/jscalendar/lang/calendar-pt.js"></script>';
		else echo '<script type="text/javascript" src="'.BASE_URL.'/lib/jscalendar/lang/calendar-en.js"></script>';
		echo '<script type="text/javascript" src="'.BASE_URL.'/lib/jscalendar/calendar-setup.js"></script>';
		include BASE_DIR.'/js/calendar.php';
		}
		
  	function mensagensNaoLidas($usuario_id = -1){
	   	if($usuario_id == -1) $usuario_id = $this->usuario_id;
	    $sql = new BDConsulta();
			$sql->adTabela('msg_usuario');
			if($this->getPref('agrupar_msg')) $sql->adCampo('count(DISTINCT msg_id)');
			else $sql->adCampo('count(msg_usuario_id)');
			$sql->adOnde('para_id '.($this->usuario_lista_dept && $this->usuario_lista_dept!=$usuario_id ? 'IN ('.$this->usuario_lista_dept.')' : '='.$usuario_id));
			$sql->adOnde('status=0');
			$total = (int)$sql->Resultado();
			$sql->limpar();		
			return $total;
    	}
    	
    function mensagensTotalCaixaEntrada($usuario_id = -1){
			if($usuario_id == -1) $usuario_id = $this->usuario_id;
			$sql = new BDConsulta();
			$sql->adTabela('msg_usuario');
			if($this->getPref('agrupar_msg')) $sql->adCampo('count(DISTINCT msg_id)');
			else $sql->adCampo('count(msg_usuario_id)');
			$sql->adOnde('para_id '.($this->usuario_lista_dept && $this->usuario_lista_dept!=$usuario_id ? 'IN ('.$this->usuario_lista_dept.')' : '='.$usuario_id));
			$sql->adOnde('status<2');
			$total = (int)$sql->Resultado();
			$sql->limpar();		
			return $total;
			}
			
	function mensagensTotalPendentes($usuario_id = -1){
    if($usuario_id == -1) $usuario_id = $this->usuario_id;
    $sql = new BDConsulta();
		$sql->adTabela('msg_usuario');
		if($this->getPref('agrupar_msg')) $sql->adCampo('count(DISTINCT msg_id)');
		else $sql->adCampo('count(msg_usuario_id)');
		$sql->adOnde('para_id '.($this->usuario_lista_dept && $this->usuario_lista_dept!=$usuario_id ? 'IN ('.$this->usuario_lista_dept.')' : '='.$usuario_id));
		$sql->adOnde('status=3');
		$total = (int)$sql->Resultado();
		$sql->limpar();		
		return $total;
		}
	}
	
/********************************************************************************************

Classe CCaixaTab_nucleo define o esqueleto do sistema de visualiza��o em abas																																							
																																												
********************************************************************************************/
class CCaixaTab_nucleo {
	var $tabs = null;
	var $ativo = null;
	var $baseHRef = null;
	var $baseInc;
	var $javascript = null;
	
	function CCaixaTab_nucleo($baseHRef = '', $baseInc = '', $ativo = 0, $javascript = null) {
		$this->tabs = array();
		$this->ativo= $ativo;
		$this->baseHRef = ($baseHRef ? $baseHRef.'&' : '?');
		$this->javascript = $javascript;
		$this->baseInc = $baseInc;
		}

	function getNomeTab($idx) {
		if (isset($this->tabs[$idx][1])) return $this->tabs[$idx][1];
		else return '';
		}

	function adicionar($arquivo, $titulo, $traduzido = false, $chave = null, $titulo2=null, $texto=null) {
		$t = array($arquivo, $titulo, $traduzido, $titulo2, $texto);
		if (isset($chave)) $this->tabs[$chave] = $t;
		else $this->tabs[] = $t;
		}

	function mostrar($extra = '', $js_tabs = false) {
		global $Aplic, $tabAtualId, $tabNomeAtual;
		$this->carregarExtras($m, $a);
		reset($this->tabs);
		$s = '';
	
		$s .= '<table cellpadding=0 cellspacing=0 width="100%"><tr>';
		if (!$somente_tab) $s .= '<td nowrap="nowrap">'.dica("Aba", "Visualizar as op��es na forma de abas. </P>M�todo prefer�ncial caso n�o deseja rolar a tela do navegador Web.").'<a class="botao" href="'.$this->baseHRef.'tab=0"><span>abas</span></a>'.dicaF().'<a class="botao" href="'.$this->baseHRef.'tab=-1"><span>lista</span></a></td>';
		$s .= $extra.'</tr></table>';
		echo $s;
	
		$s = '<table width="100%" cellpadding=0 cellspacing=0><tr>';
		if (count($this->tabs) - 1 < $this->ativo) $this->ativo= 0;
		foreach ($this->tabs as $k => $v) {
			$classe = ($k == $this->ativo) ? 'tabativo' : 'tabinativo';
			$s .= '<td width="1%" nowrap="nowrap" class="tabsp"><img src="./estilo/rondon/imagens/shim.gif" height="1" width="1" alt="" /></td>';
			$s .= '<td id="tab_s_'.$k.'" width="1%" nowrap="nowrap"';
			if ($js_tabs) $s .= ' class="'.$classe.'"';
			$s .= '><a href="';
			if ($this->javascript)	$s .= 'javascript:'.$this->javascript.'('.$this->ativo. ', '.$k.')';
			elseif ($js_tabs) $s .= 'javascript:mostrar_tab('.$k.')';
			else $s .= $this->baseHRef."tab=$k";
			$s .= '">'.$v[1].'</a></td>';
			}
		$s .= '<td nowrap="nowrap" class="tabsp">&nbsp;</td></tr>';
		$s .= '<tr><td width="100%" colspan="'.(count($this->tabs) * 2 + 1).'" class="tabox">';
		echo $s;
		if ($this->baseInc.$this->tabs[$this->ativo][0] != '') {
			$tabAtualId = $this->ativo;
			$tabNomeAtual = $this->tabs[$this->ativo][1];
			if (!$js_tabs) require $this->baseInc .$this->tabs[$this->ativo][0].'.php';
			}
		if ($js_tabs) {
			foreach ($this->tabs as $k => $v) {
				echo '<div class="tab" id="tab_'.$k.'">';
				require $this->baseInc.$v[0].'.php';
				echo '</div>';
				}
			}
		echo '</td></tr></table>';

		}

	function carregarExtras($modulo, $arquivo = null) {
		global $Aplic;
		if (!isset($_SESSION['todas_tabs']) || !isset($_SESSION['todas_tabs'][$modulo])) return false;
		if ($arquivo) {
			if (isset($_SESSION['todas_tabs'][$modulo][$arquivo]) && is_array($_SESSION['todas_tabs'][$modulo][$arquivo])) $vetor_tab = &$_SESSION['todas_tabs'][$modulo][$arquivo];
			else return false;
			} 
		else $vetor_tab = &$_SESSION['todas_tabs'][$modulo];
		$tab_contagem = 0;
		foreach ($vetor_tab as $elem_tab) {
			if (isset($elem_tab['modulo']) && $Aplic->ModuloAtivo($elem_tab['modulo'])) {
				$tab_contagem++;
				$this->adicionar($elem_tab['arquivo'], $elem_tab['nome']);
				}
			}
		return $tab_contagem;
		}

	function acharTabModulo($tab) {
		global $Aplic, $m, $a;
		if (!isset($_SESSION['todas_tabs']) || !isset($_SESSION['todas_tabs'][$m]))	return false;
		if (isset($a)) {
			if (isset($_SESSION['todas_tabs'][$m][$a]) && is_array($_SESSION['todas_tabs'][$m][$a])) $vetor_tab = &$_SESSION['todas_tabs'][$m][$a];
			else $vetor_tab = &$_SESSION['todas_tabs'][$m];
			} 
		else $vetor_tab = &$_SESSION['todas_tabs'][$m];
		list($arquivo, $nome) = $this->tabs[$tab];
		foreach ($vetor_tab as $elem_tab) {
			if (isset($elem_tab['nome']) && $elem_tab['nome'] == $nome && $elem_tab['arquivo'] == $arquivo) return $elem_tab['modulo'];
			}
		return false;
		}
	
	}
/********************************************************************************************

Classe CBlocoTitulo_core define o esqueleto do sistema de bot�es do t�tulo de cada p�gina																																							
																																												
********************************************************************************************/
class CBlocoTitulo_core {
	var $titulo = '';
	var $icone = '';
	var $modulo = '';
	var $celulas = null;
	var $ajudaref = '';

	function CBlocoTitulo_core($titulo, $icone = '', $modulo = '', $ajudaref = '') {
		$this->titulo = $titulo;
		$this->icon = $icone;
		$this->modulo = $modulo;
		$this->ajudaref = $ajudaref;
		$this->celulas1 = array();
		$this->celulas2 = array();
		$this->blocos = array();
		$this->mostrarajuda = checarModulo('ajuda', 'acesso');
		}

	function adicionaBotaoCelula($href='', $clicando='', $legenda, $icone = '', $titulo = '', $texto='', $prefixo = '', $sufixo = '') {
		$data='<table cellspacing=0 cellpadding=0><tr><td>'. dica($titulo, $texto). '<a class="botao" href="'.($href ? $href : 'javascript: void(0);').'" '.($clicando ? ' onclick="javascript:'.$clicando.'" ':'').'><span>'.($icone ? imagem($icone):'').str_ireplace(' ','&nbsp;', $legenda).'</span></a>'.dicaF().'</td></tr></table>';
		$this->celulas1[] = array('', $data, $prefixo, $sufixo);
		}
	
	
	function adicionaCelula($data = '', $atributos = '', $prefixo = '', $sufixo = '') {
		$this->celulas1[] = array($atributos, $data, $prefixo, $sufixo);
		}

	function adicionaBotao($link, $legenda, $icone = '', $titulo = '', $texto = '', $javascript='') {
		$this->blocos[] = array($legenda, $icone, $titulo, $texto, $javascript, $link);
		}

	function adicionaBotaoDireita($data = '', $atributos = '', $prefixo = '', $sufixo = '') {
		$this->celulas2[] = array($atributos, $data, $prefixo, $sufixo);
		}

	function adicionaBotaoExcluir($nome, $podeExcluir = '', $msg = '', $titulo='', $texto='') {
		global $Aplic;
		$this->adicionaBotaoDireita('<table cellspacing=0 cellpadding=0><tr><td nowrap="nowrap">'.dica($titulo, $texto).'<a class="excluir" href="javascript:excluir()" ><span>'.$nome.'</span></a>'.dicaF().'</td></tr></table>');
		}

	
	function mostrar() {
		global $Aplic, $a, $m, $tab, $infotab;
		$estilo_ui = 'rondon';
		$s = '<table width="100%" cellpadding=0 cellspacing=0><tr>';
		if ($this->icon && !$Aplic->celular) $s .= '<td width="42">'.imagem($this->icon).'</td>';
		$s .= '<td align="left" width="100%" nowrap="nowrap"><h1>'.$this->titulo.'</h1></td>';
		foreach ($this->celulas1 as $c) {
			$s .= ($c[2] ? $c[2] : '');
			$s .= '<td align="right" nowrap="nowrap"'.($c[0] ? (' '.$c[0]) : '').'>';
			$s .= ($c[1] ? $c[1] : '&nbsp;');
			$s .= '</td>';
			$s .= ($c[3] ? $c[3] : '');
			}
		$s .= '</tr></table>';
		if (count($this->blocos) || count($this->celulas2)) {
			$blocos = array();
			$s .= '<table cellpadding=0 cellspacing=0 width="100%"><tr><td height="20" nowrap="nowrap"><table cellpadding=1 cellspacing=0><tr>';
			foreach ($this->blocos as $v) {
				$t = $v[1] ? '<img src="'.acharImagem($v[1], $this->modulo).'" border="" alt="" />&nbsp;' : '';
				$t .= $v[0];
				if ($v[5]) $s .= '<td>'.dica($v[2], $v[3]).'<a class="botao" href="javascript:void(0);" onclick="url_passar(0, \''.$v[5].'\');"><span>'.$t.'</span></a>'.dicaF().'</td>';
				else $s .= '<td>'.dica($v[2], $v[3]).'<a class="botao" href="javascript:void(0);" onclick="'.$v[4].'"><span>'.$t.'</span></a>'.dicaF().'</td>';
				}
			$s .= '</tr></table></td>';
			foreach ($this->celulas2 as $c) {
				$s .= $c[2] ? $c[2] : '';
				$s .= '<td align="right" nowrap="nowrap" '.($c[0] ? ' '.$c[0] : '').'>';
				$s .= $c[1] ? $c[1] : '&nbsp;';
				$s .= '</td>';
				$s .= $c[3] ? $c[3] : '';
				}
			$s .= '</tr></table>';
			}
		echo $s;
		}

	}
?>