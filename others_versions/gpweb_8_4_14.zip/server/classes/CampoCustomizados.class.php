<?php 
/* 
Copyright (c) 2007-2011 The web2Project Development Team <w2p-developers@web2project.net>
Copyright (c) 2003-2007 The dotProject Development Team <core-developers@dotproject.net>
Copyright [2008] -  S�rgio Fernandes Reinert de Lima
Este arquivo � parte do programa gpweb
O gpweb � um software livre; voc� pode redistribu�-lo e/ou modific�-lo dentro dos termos da Licen�a P�blica Geral GNU como publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a.
Este programa � distribu�do na esperan�a que possa ser  �til, mas SEM NENHUMA GARANTIA; sem uma garantia impl�cita de ADEQUA��O a qualquer  MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU/GPL em portugu�s para maiores detalhes.
Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "licen�a GPL 2.odt", junto com este programa, se n�o, acesse o Portal do Software P�blico Brasileiro no endere�o www.softwarepublico.gov.br ou escreva para a Funda��o do Software Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/********************************************************************************************
		
gpweb\classes\CampoCustomizados.class.php		

Define a classe de CampoCustomizado que possibilita acrescentar novos campos nos diversos 
formul�rios do sistema																																	
																																												
********************************************************************************************/
if (!defined('BASE_DIR')) die('Voc� n�o deveria acessar este arquivo diretamente.');

class CampoCustomizado {
	var $campo_id;
	var $campo_ordem;
	var $campo_nome;
	var $campo_descricao;
	var $campo_formula;
	var $campo_tipo_html;
	var $campo_publicado;
	var $campo_tipo_dado;
	var $campo_tags_extras;
	var $objeto_id = null;
	var $valor_id = 0;
	var $valor_caractere;
	var $valor_inteiro;
	var $estilo;

	function CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->campo_id = $campo_id;
		$this->campo_nome = $campo_nome;
		$this->campo_ordem = $campo_ordem;
		$this->campo_descricao = $campo_descricao;
		$this->campo_formula = $campo_formula;
		$this->campo_tags_extras = $campo_tags_extras;
		$this->campo_publicado = $campo_publicado;
		}

	function load($objeto_id) {
		global $bd;
		$q = new BDConsulta;
		$q->adTabela('campos_customizados_valores');
		$q->adOnde('valor_campo_id = '.$this->campo_id);
		$q->adOnde('valor_objeto_id = '.$objeto_id);
		$rs = $q->exec();
		$linha = $q->carregarLinha();
		$q->limpar();
		$valor_id = $linha['valor_id'];
		$valor_caractere = $linha['valor_caractere'];
		$valor_inteiro = $linha['valor_inteiro'];
		if ($valor_id != null) {
			$this->valor_id = $valor_id;
			$this->valor_caractere = $valor_caractere;
			$this->valor_inteiro = $valor_inteiro;
			}
		}

	function armazenar($objeto_id) {
		global $bd;
		if ($objeto_id == null) return 'Erro: N�o foi poss�vel armazenar o campo ('.$this->campo_nome.'), id associado n�o foi suprido.';
		else {
			$ins_valorInteiro = $this->valor_inteiro == null ? '0' : $this->valor_inteiro;
			$ins_valorCaractere = $this->valor_caractere == null ? '' : stripslashes($this->valor_caractere);
			$q = new BDConsulta;
			
		
			//processar valores
			if ($this->campo_tipo_html=='valor'){
				$ins_valorCaractere=float_americano($ins_valorCaractere);
				}
			elseif ($this->campo_tipo_html=='formula'){
				$ins_valorCaractere=null;
				}
			
			if ($this->valor_id > 0) {
				$q->adTabela('campos_customizados_valores');
				$q->adAtualizar('valor_caractere', $ins_valorCaractere);
				$q->adAtualizar('valor_inteiro', $ins_valorInteiro);
				$q->adOnde('valor_id = '.$this->valor_id);
				} 
			else {
				$q->adTabela('campos_customizados_valores');
				$q->adCampo('MAX(valor_id)');
				$max_id = $q->Resultado();
				$q->limpar();
				
				$novo_valor_id = $max_id ? $max_id + 1 : 1;

				$q->adTabela('campos_customizados_valores');
				$q->adInserir('valor_id', $novo_valor_id);
				$q->adInserir('valor_modulo', '');
				$q->adInserir('valor_campo_id', $this->campo_id);
				$q->adInserir('valor_objeto_id', $objeto_id);
				$q->adInserir('valor_caractere', $ins_valorCaractere);
				$q->adInserir('valor_inteiro', $ins_valorInteiro);
				}
			$rs = $q->exec();
			$q->limpar();
			if (!$rs) return $bd->ErrorMsg().' | SQL: ';
			}
		}

	function setValorInt($v) {
		$this->valor_inteiro = $v;
		}

	function intValor() {
		return $this->valor_inteiro;
		}

	function setValor($v) {
		$this->valor_caractere = $v;
		}

	function valor() {
		return $this->valor_caractere;
		}

	function valorCaractere() {
		return $this->valor_caractere;
		}

	function setValorId($v) {
		$this->valor_id = $v;
		}

	function valorId() {
		return $this->valor_id;
		}

	function campoNome() {
		return $this->campo_nome;
		}

	function campoDescricao() {
		return $this->campo_descricao;
		}
	
	function campoFormula() {
		return $this->campo_formula;
		}

	function campoId() {
		return $this->campo_id;
		}

	function campoTipoHtml() {
		return $this->campo_tipo_html;
		}

	function campoTagExtra() {
		return $this->campo_tags_extras;
		}

	function campoOrdem() {
		return $this->campo_ordem;
		}

	function campoPublicado() {
		return $this->campo_publicado;
		}
	}

class CampoCustomizadoCaixaMarcar extends CampoCustomizado {
	function CampoCustomizadoCaixaMarcar($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'checkbox';
		}

	function getHTML($modo) {
		$html='';
		switch ($modo) {
			case 'editar':
				$bool_tag = ($this->intValor() ? 'checked="checked"': '');
				if ($this->campo_descricao) $html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td><input type="checkbox" name="'.$this->campo_nome.'" value="1" '.$bool_tag.$this->campo_tags_extras.'/></td></tr>';
				break;
			case 'ver':
				if ($this->campo_descricao) $html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td '.($this->estilo ? $this->estilo : 'class="realce"').' width="100%">'.($this->intValor() ? 'Sim': 'N�o').'</td></tr>';
				break;
			}
		return $html;
		}

	function setValor($v) {
		$this->valor_inteiro = $v;
		}
	}

class CampoCustomizadoTexto extends CampoCustomizado {
	function CampoCustomizadoTexto($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'textinput';
		}

	function getHTML($modo) {
		$html ='';
		switch ($modo) {
			case 'editar':
				$html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td><input type="text" class="texto" name="'.$this->campo_nome.'" value="'.$this->valorCaractere().'" '.($this->campo_tags_extras ? $this->campo_tags_extras : 'size="25"').' /></td></tr>';
				break;
			case 'ver':
				if ($this->valorCaractere()) $html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td '.($this->estilo ? $this->estilo : 'class="realce"').' width="100%">'.$this->valorCaractere();
				break;
			}
		return $html;
		}
	}

class CampoCustomizadoAreaTexto extends CampoCustomizado {
	
	function CampoCustomizadoAreaTexto($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'textarea';
		}

	function getHTML($modo) {
		$html ='';
		switch ($modo) {
			case 'editar':
				$html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td><textarea name="'.$this->campo_nome.'" '.($this->campo_tags_extras ? $this->campo_tags_extras : 'cols="40" rows="4" class="texto"').'>'.$this->valorCaractere().'</textarea></td></tr>';
				break;
			case 'ver':
				if ($this->valorCaractere()) $html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td '.($this->estilo ? $this->estilo : 'class="realce"').' width="100%">'.nl2br($this->valorCaractere()).'</td></tr>';
				break;
			}
		return $html;
		}
	
	}

	
class CampoCustomizadoFormula extends CampoCustomizado {
	
	function CampoCustomizadoFormula($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'formula';
		}

	function getHTML($modo) {
		global $config;
		$html ='';
		switch ($modo) {
			case 'editar':
				//$html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td><input type="text" class="texto" readonly onkeypress="return entradaNumerica(event, this, true, true);" name="'.$this->campo_nome.'" value="'.$this->valorCaractere().'" '.($this->campo_tags_extras ? $this->campo_tags_extras : 'size="25"').' /></td></tr>';
				break;
			case 'ver':
				
				//ver($this);
				$sql = new BDConsulta;
				$sql->adTabela('campos_customizados_valores');
				$sql->esqUnir('campos_customizados_estrutura', 'campos_customizados_estrutura', 'valor_campo_id=campo_id');
				$sql->adCampo('campo_id, valor_caractere');
				$sql->adOnde('valor_objeto_id = '.$this->campo_id);
				$sql->adOnde('campo_tipo_html = \'valor\'');
				//ver3($sql);
				$variaveis=$sql->listaVetorChave('campo_id','valor_caractere');
				$sql->limpar();
		
				$formula=$this->campo_formula;
				
				foreach($variaveis as $campoid => $valor_caractere){
					$chave='I'.($campoid < 10 ? '0' : '').$campoid;	
					$formula=str_replace($chave , $valor_caractere, $formula);
					}			
				$resultado=$this->calcular_string($formula);
			
				$html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td '.($this->estilo ? $this->estilo : 'class="realce"').' width="100%">'.$config['simbolo_moeda'].' '.number_format($resultado, 2, ',', '.');
				break;
			}
		return $html;
		}
	
	function calcular_string($texto){
    $texto = trim($texto); 
    if (!$texto)return 0;

    for($i = 0; $i < strlen($texto); $i++){
    	if (isset($texto[$i]) && $texto[$i]=='I' && isset($texto[$i+1]) && is_int($texto[$i+1]) && isset($texto[$i+2]) &&is_int($texto[$i+2])) { 		  		
    		$texto[$i]='0';
    		$texto[$i+1]='.';
    		$texto[$i+2]='0';
    		}
    	}	
    $valor=0;
    $computar = @create_function("", "return (".$texto.");");
    $valor=( function_exists($computar) ? @$computar() :  0); 
    return 0 + $valor;
		}
	
	
	}	
	
	
class CampoCustomizadoValor extends CampoCustomizado {
	
	function CampoCustomizadoValor($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'valor';
		}

	function getHTML($modo) {
		global $config;
		$html ='';
		switch ($modo) {
			case 'editar':
				$html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td><input type="text" class="texto" onkeypress="return entradaNumerica(event, this, true, true);" name="'.$this->campo_nome.'" value="'.$this->valorCaractere().'" '.($this->campo_tags_extras ? $this->campo_tags_extras : 'size="25"').' /></td></tr>';
				break;
			case 'ver':
				if ($this->valorCaractere()) $html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td '.($this->estilo ? $this->estilo : 'class="realce"').' width="100%">'.$config['simbolo_moeda'].' '.number_format($this->valorCaractere(), 2, ',', '.');
				break;
			}
		return $html;
		}
	
	}	

class CampoCustomizadoLegenda extends CampoCustomizado {
	function CampoCustomizadoLegenda($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'label';
		}

	function getHTML($modo) {
		if ($this->campo_descricao) return '<tr><td nowrap="nowrap" align="right"><span '.$this->campo_tags_extras.'>'.$this->campo_descricao.'</span></td></tr>';
		else return '';
		}
	
	}

class CampoCustomizadoSeparador extends CampoCustomizado {
	function CampoCustomizadoSeparador($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'separator';
		}

	function getHTML($modo) {
		return '<tr><td colspan="2"><hr '.$this->campo_tags_extras.' /></td></tr>';
		}
	
	}

class CampoCustomizadoSelecionar extends CampoCustomizado {
	var $opcoes;
	function CampoCustomizadoSelecionar($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'select';
		$this->options = new ListaOpcoesCustomizadas($campo_id);
		$this->options->load();
		}

	function getHTML($modo) {
		$html='';
		switch ($modo) {
			case 'editar':
				$html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td>'.$this->options->getHTML($this->campo_nome, $this->intValor()).'</td></tr>';
				break;
			case 'ver':
				if ($this->options->itemNoIndice($this->intValor())) $html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td '.($this->estilo ? $this->estilo : 'class="realce"').' width="100%">'.$this->options->itemNoIndice($this->intValor()).'</td></tr>';
				break;
			}
		return $html;
		}

	function setValor($v) {
		$this->valor_inteiro = $v;
		}

	function valor() {
		return $this->valor_inteiro;
		}
	}

class CampoCustomizadoLinkWeb extends CampoCustomizado {
	function CampoCustomizadoLinkWeb($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado) {
		$this->CampoCustomizado($campo_id, $campo_nome, $campo_ordem, $campo_descricao, $campo_formula, $campo_tags_extras, $campo_publicado);
		$this->campo_tipo_html = 'href';
		}

	function getHTML($modo) {
		$html='';
		switch ($modo) {
			case 'editar':
				$html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td><input type="text" class="texto" name="'.$this->campo_nome.'" value="'.$this->valorCaractere().'" ' .($this->campo_tags_extras ? $this->campo_tags_extras : 'size="25"'). ' /></td></tr>';
				break;
			case 'ver':
				if(strpos($this->campoTagExtra(),'{'.$this->campoNome().'}') && $this->valorCaractere()) {
					$html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td '.($this->estilo ? $this->estilo : 'class="realce"').' width="100%"><a href="'.str_replace('{'.$this->campoNome().'}', $this->valorCaractere(), $this->campoTagExtra()).'" target="_blank">'.$this->valorCaractere().'</a></td></tr>';
					}
				else if ($this->valorCaractere()) $html = '<tr><td nowrap="nowrap" align="right">'.dica($this->campo_descricao, 'Campo customizado').$this->campo_descricao.': </td><td '.($this->estilo ? $this->estilo : 'class="realce"').' width="100%"><a href="'.$this->valorCaractere().'">'.$this->valorCaractere().'</a></td></tr>';
				break;
			}
		return $html;
		}
	
	}

class CampoCustomizados {
	var $m;
	var $a;
	var $modo;
	var $obj_id;
	var $ordem;
	var $publicado;
	var $campos;

	function CampoCustomizados($m, $obj_id = null, $modo = 'editar', $publicado = 0) {
		$this->m = $m;
		$this->obj_id = $obj_id;
		$this->modo = $modo;
		$this->publicado = $publicado;
		$q = new BDConsulta;
		$q->adTabela('campos_customizados_estrutura');
		$q->adOnde('campo_modulo = \''.$this->m.'\' AND campo_pagina = \'editar\'');
		if ($publicado)	$q->adOnde('campo_publicado = 1');
		$q->adOrdem('campo_ordem ASC');
		$linhas = $q->Lista();
		if ($linhas == null) {	} 
		else {
			foreach ($linhas as $linha) {
				switch ($linha['campo_tipo_html']) {
					case 'checkbox':
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoCaixaMarcar($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;
					case 'href':
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoLinkWeb($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;
					case 'textarea':
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoAreaTexto($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;
					case 'select':
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoSelecionar($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;
					case 'label':
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoLegenda($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;
					case 'separator':
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoSeparador($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;
					case 'valor':
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoValor($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;	
					case 'formula':
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoFormula($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;		
					default:
						$this->campos[$linha['campo_nome']] = new CampoCustomizadoTexto($linha['campo_id'], $linha['campo_nome'], $linha['campo_ordem'], stripslashes($linha['campo_descricao']), stripslashes($linha['campo_formula']), stripslashes($linha['campo_tags_extras']), $linha['campo_ordem'], $linha['campo_publicado']);
						break;
					}
				}
			if ($obj_id > 0) {
				foreach ($this->campos as $chave => $cCampo) $this->campos[$chave]->load($this->obj_id);
				}
			}
		}

	function adicionar($campo_nome, $campo_descricao, $campo_formula, $campo_tipo_html, $campo_tipo_dado, $campo_tags_extras, $campo_ordem, $campo_publicado, &$erro_msg) {
		global $bd, $Aplic;
		$q = new BDConsulta;
		$q->adTabela('campos_customizados_estrutura');
		$q->adCampo('MAX(campo_id)');
		$max_id = $q->Resultado();
		$next_id = ($max_id ? $max_id + 1 : 1);
		$campo_ordem = ($campo_ordem ? $campo_ordem : 1);
		$campo_publicado = ($campo_publicado ? 1 : 0); 
		$campo_a = 'editar';

		$q = new BDConsulta;
		$q->adTabela('campos_customizados_estrutura');
		$q->adInserir('campo_id', $next_id);
		$q->adInserir('campo_modulo', $this->m);
		$q->adInserir('campo_pagina', $campo_a);
		$q->adInserir('campo_tipo_html', $campo_tipo_html);
		$q->adInserir('campo_tipo_dado', $campo_tipo_dado);
		$q->adInserir('campo_ordem', $campo_ordem);
		$q->adInserir('campo_nome', $campo_nome);
		$q->adInserir('campo_descricao', $campo_descricao);
		$q->adInserir('campo_formula', $campo_formula);
		$q->adInserir('campo_tags_extras', $campo_tags_extras);
		$q->adInserir('campo_ordem', $campo_ordem);
		$q->adInserir('campo_publicado', $campo_publicado);
		if (!$q->exec()) {
			$erro_msg = $bd->ErrorMsg();
			$q->limpar();
			return 0;
			} 
		
    $q->limpar();
    
    if($Aplic->profissional && ($campo_tipo_html == 'select' || $campo_tipo_html == 'textinput' || $campo_tipo_html == 'textarea')){
      //adiciona como op��o para os formul�rios
      $q->adTabela('campo_formulario');
      $q->adInserir('campo_formulario_ativo', '0');
      $q->adInserir('campo_formulario_campo', $campo_nome.'_ex');
      $q->adInserir('campo_formulario_tipo', $this->m.'_ex');
      $q->adInserir('campo_formulario_descricao', $campo_descricao);
      $q->adInserir('campo_formulario_customizado_id', $next_id);
      $q->exec();
      $q->limpar();
      }
    
    return $next_id;
		}

	function atualizar($campo_id, $campo_nome, $campo_descricao, $campo_formula, $campo_tipo_html, $campo_tipo_dado, $campo_tags_extras, $campo_ordem, $campo_publicado, &$erro_msg) {
		global $bd, $Aplic;
		$q = new BDConsulta;
		$q->adTabela('campos_customizados_estrutura');
		$q->adAtualizar('campo_nome', $campo_nome);
		$q->adAtualizar('campo_descricao', $campo_descricao);
		$q->adAtualizar('campo_formula', $campo_formula);
		$q->adAtualizar('campo_tipo_html', $campo_tipo_html);
		$q->adAtualizar('campo_tipo_dado', $campo_tipo_dado);
		$q->adAtualizar('campo_tags_extras', $campo_tags_extras);
		$q->adAtualizar('campo_ordem', $campo_ordem);
		$q->adAtualizar('campo_publicado', $campo_publicado);
		$q->adOnde('campo_id = '.$campo_id);
		if (!$q->exec()) {
			$erro_msg = $bd->ErrorMsg();
			$q->limpar();
			return 0;
			} 
		
    $q->limpar();
    
    if($Aplic->profissional && ($campo_tipo_html == 'select' || $campo_tipo_html == 'textinput' || $campo_tipo_html == 'textarea')){
      //adiciona como op��o para os formul�rios
      $q->adTabela('campo_formulario');
      $q->adAtualizar('campo_formulario_campo', $campo_nome.'_ex');
      $q->adAtualizar('campo_formulario_descricao', $campo_descricao);
      $q->adOnde('campo_formulario_customizado_id', $campo_id);
      $q->exec();
      $q->limpar();
      
      return $campo_id;
      }
		}

	function campoComId($campo_id) {
		foreach ($this->campos as $k => $v) {
			if ($this->campos[$k]->campo_id == $campo_id) return $this->campos[$k];
			}
		}

	function join(&$variaveis) {
		if (!count($this->campos) == 0) {
			foreach ($this->campos as $k => $v) $this->campos[$k]->setValor(@$variaveis[$k]);
			}
		}

	function armazenar($objeto_id) {
		if (!count($this->campos) == 0) {
			$armazenar_erros = '';
			foreach ($this->campos as $k => $cf) {
				$resultado = $this->campos[$k]->armazenar($objeto_id);
				if ($resultado) $armazenar_erros .= 'Erro ao armazenar o campo customizado '.$k.':'.$resultado;
				}
			if ($armazenar_erros) echo $armazenar_erros;
			}
		}

	function excluirCampo($campo_id) {
		global $bd;
		$q = new BDConsulta;
		$q->setExcluir('campos_customizados_estrutura');
		$q->adOnde('campo_id = '.$campo_id);
		if (!$q->exec()) {
			$q->limpar();
			return $bd->ErrorMsg();
			}
      
    $q->setExcluir('campo_formulario');
    $q->adOnde('campo_formulario_customizado_id = '.$campo_id);
		}

	function count() {
		return count($this->campos);
		}

	function getHTML() {
		if ($this->count() == 0) return '';
		else {
			$html = '';
			foreach ($this->campos as $cCampo) {
				if (!$this->publicado) $html .=  $cCampo->getHTML($this->modo);
				else $html .= $cCampo->getHTML($this->modo);
				}
			return $html;
			}
		}

	function imprimirHTML() {
		$html = $this->getHTML();
		echo $html;
		}


	}

class ListaOpcoesCustomizadas {
	var $campo_id;
	var $opcoes;

	function ListaOpcoesCustomizadas($campo_id) {
		$this->campo_id = $campo_id;
		$this->options = array();
		}

	function load($oid = null, $tira = true) {
		global $bd;
		$q = new BDConsulta;
		$q->adTabela('campos_customizados_listas');
		$q->adOnde('campo_id = '.$this->campo_id);
		$q->adOrdem('lista_valor');
		$opcoes=$q->lista();
		$q->limpar();
		$this->options = array();
		foreach($opcoes as $linha) $this->options[$linha['lista_opcao_id']] = $linha['lista_valor'];
		}

	function armazenar($atualizarNulos = false) {
		global $bd;
		if (!is_array($this->options))	$this->options = array();
		
	
		$q = new BDConsulta;
		
		$q->setExcluir('campos_customizados_listas');
		$q->adOnde('campo_id = '.$this->campo_id);
		$q->exec();
		$q->limpar();
		
		
 		$erro_insercao ='';
		foreach ($this->options as $chave => $opt) {
			$q = new BDConsulta;
			$q->adTabela('campos_customizados_listas');
			$q->adInserir('campo_id', $this->campo_id);
			$q->adInserir('lista_opcao_id', $chave);
			$q->adInserir('lista_valor', db_escape(strip_tags($opt)));
			if (!$q->exec()) $erro_insercao = $bd->ErrorMsg();
			$q->limpar();
			}
		
		return $erro_insercao;
		}

	function excluir() {
		$q = new BDConsulta;
		$q->setExcluir('campos_customizados_listas');
		$q->adOnde('campo_id = '.$this->campo_id);
		$q->exec();
		$q->limpar();
		}

	function setOpcoes($opcao_array) {
		$this->options = $opcao_array;
		}

	function getOpcoes() {
		return $this->options;
		}

	function itemNoIndice($i) {
		if (isset($this->options[$i])) return $this->options[$i];
		}

	function getHTML($campo_nome, $selecionado) {
		$html = '<select class="texto" name="'.$campo_nome.'">';
		foreach ($this->options as $i => $opt) {
			$html .= "\t".'<option value="'.$i.'"';
			if ($i == $selecionado) $html .= ' selected="selected" ';
			$html .= '>'.$opt.'</option>';
			}
		$html .= '</select>';
		return $html;
		}
	}
?>