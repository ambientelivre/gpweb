SET FOREIGN_KEY_CHECKS=0;
UPDATE versao SET versao_codigo='8.0.39'; 
UPDATE versao SET ultima_atualizacao_bd='2012-10-26'; 
UPDATE versao SET ultima_atualizacao_codigo='2012-10-26'; 
UPDATE versao SET versao_bd=128; 

DELETE FROM pratica_nos_marcadores;

ALTER TABLE pratica_nos_marcadores ADD COLUMN uuid VARCHAR(36) DEFAULT NULL;
ALTER TABLE pratica_nos_verbos ADD COLUMN uuid VARCHAR(36) DEFAULT NULL;


ALTER TABLE pratica_nos_marcadores ADD COLUMN ano INTEGER(4) DEFAULT NULL;
ALTER TABLE pratica_nos_verbos ADD COLUMN ano INTEGER(4) DEFAULT NULL;

UPDATE pratica_nos_marcadores SET ano='2012';




ALTER TABLE praticas DROP COLUMN pratica_controle;
ALTER TABLE praticas DROP COLUMN pratica_desde_quando;
ALTER TABLE praticas DROP COLUMN pratica_metodo_aprendizado;
ALTER TABLE praticas DROP COLUMN pratica_melhorias;
ALTER TABLE praticas DROP COLUMN pratica_controlada;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_controlada;
ALTER TABLE praticas DROP COLUMN pratica_adequada;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_adequada;
ALTER TABLE praticas DROP COLUMN pratica_proativa;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_proativa;
ALTER TABLE praticas DROP COLUMN pratica_abrage_pertinentes;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_abrangencia;
ALTER TABLE praticas DROP COLUMN pratica_continuada;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_continuada;
ALTER TABLE praticas DROP COLUMN pratica_refinada;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_refinada;
ALTER TABLE praticas DROP COLUMN pratica_coerente;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_coerente;
ALTER TABLE praticas DROP COLUMN pratica_interrelacionada;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_interrelacionada;
ALTER TABLE praticas DROP COLUMN pratica_cooperacao;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_cooperacao;
ALTER TABLE praticas DROP COLUMN pratica_cooperacao_partes;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_cooperacao_partes;
ALTER TABLE praticas DROP COLUMN pratica_arte;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_arte;
ALTER TABLE praticas DROP COLUMN pratica_inovacao;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_inovacao;
ALTER TABLE praticas DROP COLUMN pratica_melhoria_aprendizado;
ALTER TABLE praticas DROP COLUMN pratica_justificativa_melhoria_aprendizado;


DROP TABLE IF EXISTS pratica_indicador_requisito;

CREATE TABLE pratica_indicador_requisito (
  pratica_indicador_id INTEGER(100) UNSIGNED DEFAULT NULL,
  ano INTEGER(4) NOT NULL DEFAULT '0',
  pratica_indicador_quando TEXT,
  pratica_indicador_oque TEXT,
  pratica_indicador_como TEXT,
  pratica_indicador_onde TEXT,
  pratica_indicador_quanto TEXT,
  pratica_indicador_porque TEXT,
  pratica_indicador_quem TEXT,
  pratica_indicador_melhorias TEXT,
  pratica_indicador_referencial TEXT,
  pratica_indicador_relevante TINYINT(1) DEFAULT 0,
  pratica_indicador_justificativa_relevante TEXT,
  pratica_indicador_lider TINYINT(1) DEFAULT 0,
  pratica_indicador_justificativa_lider TEXT,
  pratica_indicador_excelencia TINYINT(1) DEFAULT 0,
  pratica_indicador_justificativa_excelencia TEXT,
  pratica_indicador_atendimento TINYINT(1) DEFAULT 0,
  pratica_indicador_justificativa_atendimento TEXT,
  pratica_indicador_estrategico TINYINT(1) DEFAULT 0,
  pratica_indicador_justificativa_estrategico TEXT,
  pratica_indicador_descricao TEXT,
  PRIMARY KEY (pratica_indicador_id, ano),
  KEY pratica_indicador_id (pratica_indicador_id),
  CONSTRAINT pratica_indicador_requisito_fk FOREIGN KEY (pratica_indicador_id) REFERENCES pratica_indicador (pratica_indicador_id) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=InnoDB;

DROP TABLE IF EXISTS pratica_requisito;

CREATE TABLE pratica_requisito (
	pratica_id INTEGER(100) UNSIGNED NOT NULL,
	ano INTEGER(4) DEFAULT null,
	pratica_oque TEXT,
	pratica_onde TEXT,
	pratica_quando TEXT,
	pratica_como TEXT,
	pratica_porque TEXT,
	pratica_quanto TEXT,
	pratica_quem TEXT,
	pratica_descricao TEXT,
	pratica_controlada TINYINT(1) DEFAULT 0,
  pratica_justificativa_controlada TEXT,
  pratica_proativa TINYINT(1) DEFAULT 0,
  pratica_justificativa_proativa TEXT,
  pratica_abrage_pertinentes TINYINT(1) DEFAULT 0,
  pratica_justificativa_abrangencia TEXT,
  pratica_continuada TINYINT(1) DEFAULT 0,
  pratica_justificativa_continuada TEXT,
  pratica_refinada TINYINT(1) DEFAULT 0,
  pratica_justificativa_refinada TEXT,
  pratica_coerente TINYINT(1) DEFAULT 0,
  pratica_justificativa_coerente TEXT,
  pratica_interrelacionada TINYINT(1) DEFAULT 0,
  pratica_justificativa_interrelacionada TEXT,
  pratica_cooperacao TINYINT(1) DEFAULT 0,
  pratica_justificativa_cooperacao TEXT,
  pratica_cooperacao_partes TINYINT(1) DEFAULT 0,
  pratica_justificativa_cooperacao_partes TEXT,
  pratica_arte TINYINT(1) DEFAULT 0,
  pratica_justificativa_arte TEXT,
  pratica_inovacao TINYINT(1) DEFAULT 0,
  pratica_justificativa_inovacao TEXT,
  pratica_melhoria_aprendizado TINYINT(1) DEFAULT 0,
  pratica_justificativa_melhoria_aprendizado TEXT,
  PRIMARY KEY (pratica_id, ano),
  KEY pratica_id (pratica_id),
	CONSTRAINT pratica_requisito_fk FOREIGN KEY (pratica_id) REFERENCES praticas (pratica_id) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=InnoDB;




INSERT INTO pratica_regra_campo (pratica_regra_campo_modelo_id, pratica_regra_campo_nome, pratica_regra_campo_texto, pratica_regra_campo_descricao, pratica_regra_campo_resultado) VALUES 
  (8,'pratica_adequada','Adequa��o','Atendimento consistente aos requisitos propostos, i.e., realiza��o das fun��es relativas aos processos gerenciais requeridos, com mecanismo de controle, atendendo a eventuais especifcidades requeridas e apresentando eventuais informa��es e destaques solicitados, de forma adequada ao perfil da organiza��o',0),
	(8,'pratica_proativa','Proativade','Capacidade de antecipar-se aos fatos, a fim de prevenir a ocorr�ncia de situa��es potencialmente indesej�veis e aumentar a confan�a e a previsibilidade dos processos gerenciais',0),
	(8,'pratica_continuada','Continuidade','Utiliza��o peri�dica e ininterrupta, considerando-se a realiza��o de pelo menos um ciclo completo',0),
	(8,'pratica_abrage_pertinentes','Abrang�ncia','Cobertura ou escopo suficientes, horizontal ou vertical, conforme pertinente a cada processo gerencial requerido pelas �reas, processos, produtos ou partes interessadas, considerando-se o perfil da organiza��o e estrat�gias',0),
	(8,'pratica_refinada','Refinamento','Aperfei�oamento decorrente dos processos de melhoria e inova��o',0),
	(8,'pratica_melhoria_aprendizado','Melhorias pelo aprendizado','Melhorias implementadas foram decorrentes do aprendizado, ao se girar o ciclo PDCA',0),
	(8,'pratica_coerente','Coer�ncia','Rela��o harm�nica com as estrat�gias e objetivos da organiza��o, incluindo valores e princ�pios',0),
	(8,'pratica_interrelacionada','Inter-relacionamento','implementa��o de modo complementar com outras pr�ticas de gest�o da organiza��o, onde apropriado',0),
	(8,'pratica_cooperacao','Coopera��o','Colabora��o entre as �reas da organiza��o na implementa��o ? planejamento, execu��o, controle ou aperfei�oamento ? das pr�ticas de gest�o',0),
	(8,'pratica_indicador_relevante','Relev�ncia','Grau em que os resultados apresentados s�o importantes para a determina��o do alcance dos objetivos estrat�gicos e operacionais da organiza��o',1),
	(8,'pratica_indicador_favoravel','Tend�ncia favor�vel','Grau em que os resultados relevantes apresentados demonstram evolu��o favor�vel ao longo de, pelo menos, tr�s �ltimos per�odos consecutivos. Esses per�odos devem ser coerentes com ciclos de planejamento e de an�lise do desempenho na organiza��o',1),
	(8,'pratica_indicador_ser_superior','Competitivo','N�veis de resultados superiores, no mercado ou setor de atua��o, evidenciados por meio de referenciais comparativos pertinentes',1),
	(8,'pratica_indicador_lider','Lider','Posi��o de lideran�a de mercado, ou do setor de atua��o, em que as for�as do macroambiente criam condi��es similares de competi��o, por clientes, oportunidades ou recursos de qualquer natureza, na regi�o de atua��o',1);
