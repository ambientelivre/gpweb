
UPDATE versao SET versao_bd=8;  
INSERT INTO config (config_nome, config_valor, config_grupo, config_tipo) VALUES 
('email_ativo','false','email','checkbox');