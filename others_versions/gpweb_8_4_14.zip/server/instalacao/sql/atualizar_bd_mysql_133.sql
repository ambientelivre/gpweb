SET FOREIGN_KEY_CHECKS=0;
UPDATE versao SET versao_codigo='8.1.3'; 
UPDATE versao SET ultima_atualizacao_bd='2012-11-25'; 
UPDATE versao SET ultima_atualizacao_codigo='2012-11-25'; 
UPDATE versao SET versao_bd=133; 

