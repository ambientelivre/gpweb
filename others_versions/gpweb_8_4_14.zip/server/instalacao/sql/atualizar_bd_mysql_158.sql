SET FOREIGN_KEY_CHECKS=0;

UPDATE versao SET versao_codigo='8.3.6'; 
UPDATE versao SET ultima_atualizacao_bd='2013-05-05'; 
UPDATE versao SET ultima_atualizacao_codigo='2013-05-05'; 
UPDATE versao SET versao_bd=158;
