UPDATE versao SET versao_bd=31; 
UPDATE versao SET versao_codigo='5.2'; 

DROP TABLE IF EXISTS wbs;
