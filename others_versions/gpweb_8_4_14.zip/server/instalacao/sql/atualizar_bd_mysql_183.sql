SET FOREIGN_KEY_CHECKS=0;

UPDATE versao SET versao_codigo='8.3.21'; 
UPDATE versao SET ultima_atualizacao_bd='2013-09-15'; 
UPDATE versao SET ultima_atualizacao_codigo='2013-09-15'; 
UPDATE versao SET versao_bd=183;