SET FOREIGN_KEY_CHECKS=0;

UPDATE versao SET versao_codigo='8.4.05'; 
UPDATE versao SET ultima_atualizacao_bd='2014-02-05'; 
UPDATE versao SET ultima_atualizacao_codigo='2014-02-05'; 
UPDATE versao SET versao_bd=207;