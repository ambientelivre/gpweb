UPDATE versao SET versao_bd=45; 
UPDATE versao SET versao_codigo='7.5.1'; 