UPDATE versao SET versao_bd=30; 
UPDATE versao SET versao_codigo='5.0'; 
