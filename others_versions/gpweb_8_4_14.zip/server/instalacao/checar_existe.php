<?php
/* 
Copyright (c) 2007-2011 The web2Project Development Team <w2p-developers@web2project.net>
Copyright (c) 2003-2007 The dotProject Development Team <core-developers@dotproject.net>
Copyright [2008] -  S�rgio Fernandes Reinert de Lima
Este arquivo � parte do programa gpweb
O gpweb � um software livre; voc� pode redistribu�-lo e/ou modific�-lo dentro dos termos da Licen�a P�blica Geral GNU como publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a.
Este programa � distribu�do na esperan�a que possa ser  �til, mas SEM NENHUMA GARANTIA; sem uma garantia impl�cita de ADEQUA��O a qualquer  MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU/GPL em portugu�s para maiores detalhes.
Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "licen�a GPL 2.odt", junto com este programa, se n�o, acesse o Portal do Software P�blico Brasileiro no endere�o www.softwarepublico.gov.br ou escreva para a Funda��o do Software Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/********************************************************************************************
		
gpweb\instalacao\checar_existe.php		

Checar se j� existe a base de dados
																																												
********************************************************************************************/

require_once '../base.php';
require_once BASE_DIR.'/codigo/instalacao.inc.php';


if (is_file('../config.php')) require_once '../config.php';
if (!isset($config['militar'])) require_once 'config-dist.php';


echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">';
echo '<head>';
echo '<meta name="Description" content="gpweb Default Style" />';
echo '<meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1" />';
echo '<title>'.(isset($config['gpweb']) ? $config['gpweb'] : 'gpweb').'</title>';
echo '<link rel="stylesheet" type="text/css" href="../estilo/rondon/estilo.css" media="all" />';
echo '<style type="text/css" media="all">@import "../estilo/rondon/estilo.css";</style>';
echo '<link rel="shortcut icon" href="../estilo/rondon/imagens/organizacao/10/favicon.ico" type="image/ico" />';
echo '<script type="text/javascript" src="../lib/mootools/mootools.js"></script>';
echo '</head>';




$tipoCia = (isset($_REQUEST['tipoCia']) ? $_REQUEST['tipoCia']  : $config['militar']);
$militar=$tipoCia;
$config['popup_ativado']=true;

require_once BASE_DIR.'/estilo/rondon/funcao_grafica.php';
require_once BASE_DIR.'/incluir/funcoes_principais.php';
$fazer_bd =$_REQUEST['fazer_bd'];
$fazer_bd_cfg = $_REQUEST['fazer_bd_cfg'];
$fazer_cfg = $_REQUEST['fazer_cfg'];
$modo = instalacao_getParametro($_REQUEST, 'modo', '0');
$exemplo = instalacao_getParametro($_REQUEST, 'exemplo', false);
$restrito = instalacao_getParametro($_REQUEST, 'restrito', false);
$tipoBd = trim(instalacao_getParametro( $_REQUEST, 'tipoBd', 'mysql'));
$usuarioBd = trim( instalacao_getParametro( $_REQUEST, 'usuarioBd', 'root'));
$senhaBd = trim(instalacao_getParametro( $_REQUEST, 'senhaBd', ''));
$hospedadoBd = trim(instalacao_getParametro( $_REQUEST, 'hospedadoBd', ''));
$nomeBd = trim(instalacao_getParametro( $_REQUEST, 'nomeBd', ''));
$prefixoBd = trim(instalacao_getParametro( $_REQUEST, 'prefixoBd', ''));
$dbdrop = instalacao_getParametro($_REQUEST, 'dbdrop', false); 
$persistenteBd = instalacao_getParametro($_REQUEST, 'persistenteBd', false);

require_once( BASE_DIR.'/lib/adodb/adodb.inc.php');
@include_once BASE_DIR.'/incluir/versao.php';
$bd = NewADOConnection($tipoBd);
$bd_existente=0;
if(!empty($bd)) {
  $dbc = $bd->Connect($hospedadoBd,$usuarioBd,$senhaBd);
  if ($dbc) $bd_existente = $bd->SelectDB($nomeBd);
	} 


if(!$bd_existente || $fazer_cfg){
	include_once BASE_DIR.'/instalacao/fazer_instalar_bd.php';
	exit();
	}




$localidade_tipo_caract='iso-8859-1';

echo '<body>';

echo '<form name="instFrm" action="fazer_instalar_bd.php" method="post">';
echo '<input type="hidden" name="fazer_bd" value="'.$fazer_bd.'" />';
echo '<input type="hidden" name="fazer_bd_cfg" value="'.$fazer_bd_cfg.'" />';
echo '<input type="hidden" name="fazer_cfg" value="'.$fazer_cfg.'" />';
echo '<input type="hidden" name="modo" value="'.$modo.'" />';
echo '<input type="hidden" name="exemplo" value="'.$exemplo.'" />';
echo '<input type="hidden" name="restrito" value="'.$restrito.'" />';
echo '<input type="hidden" name="tipoBd" value="'.$tipoBd.'" />';
echo '<input type="hidden" name="usuarioBd" value="'.$usuarioBd.'" />';
echo '<input type="hidden" name="senhaBd" value="'.$senhaBd.'" />';
echo '<input type="hidden" name="hospedadoBd" value="'.$hospedadoBd.'" />';
echo '<input type="hidden" name="nomeBd" value="'.$nomeBd.'" />';
echo '<input type="hidden" name="prefixoBd" value="'.$prefixoBd.'" />';
echo '<input type="hidden" name="dbdrop" value="'.$dbdrop.'" />';
echo '<input type="hidden" name="persistenteBd" value="'.$persistenteBd.'" />';
echo '<input type="hidden" name="tipoCia" value="'.$tipoCia.'" />';

echo '<table width="100%" cellspacing=0 cellpadding=0 border=0><tr><td align=center>'.dica('Site do Sistema', 'Clique para entrar no site oficial do Sistema.').'<a href="http://www.sistemagpweb.com" target="_blank"><img border=0 alt="gpweb" src="../estilo/rondon/imagens/organizacao/10/gpweb_logo.png"/></a>'.dicaF().'</td></tr><tr><td>&nbsp;</td></tr></table>';
echo '<table width="95%" cellspacing=0 cellpadding=0 border=0 align="center">';
echo '<tr><td colspan="2">'.estiloTopoCaixa('100%','../').'</td></tr>';
echo '<tr><td>';
echo '<table cellspacing="6" cellpadding="3" border=0 class="std" align="center" width="100%">';
echo '<tr><td><h1>J� existe uma base de dados do gpweb instalada!</h1></td></tr>';
echo '<tr><td><h2>Caso continue a instala��o, todos os dados existentes na base de dados ser�o perdidos.</h2></td></tr>';
echo '<tr><td align="left"><table><tr><td>'.botao('<b>continuar</b>', 'Continuar', 'Continuar a instala��o da nova a base de dados, apagando os dados anteriores.','','instFrm.submit()').'</td><td style="width:400px;">&nbsp;</td><td>'.botao('<b>abortar</b>', 'Abortar', 'Abortar a instala��o da nova a base de dados, preservando os dados anteriores.','','voltar();').'</td></tr></table></td></tr>';



echo '</table></td></tr><table width="95%" cellspacing=0 cellpadding=0 border=0 align="center"><tr><td colspan="2">'.estiloFundoCaixa('100%','../').'</td></tr></table></form>';
echo '<script type="text/javascript">window.addEvent(\'domready\', function(){var as = []; $$(\'span\').each(function(span){if (span.getAttribute(\'title\')) as.push(span);});new Tips(as), {	}});</script>';
echo '</body></html>';
?>
<script type="text/javascript">
	
function voltar(){
	window.open("index.php", '_self');
	}	
</script>	