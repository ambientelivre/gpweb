<?php
/* 
Copyright [2008] -  S�rgio Fernandes Reinert de Lima
Este arquivo � parte do programa gpweb
O gpweb � um software livre; voc� pode redistribu�-lo e/ou modific�-lo dentro dos termos da Licen�a P�blica Geral GNU como publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a.
Este programa � distribu�do na esperan�a que possa ser  �til, mas SEM NENHUMA GARANTIA; sem uma garantia impl�cita de ADEQUA��O a qualquer  MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU/GPL em portugu�s para maiores detalhes.
Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "licen�a GPL 2.odt", junto com este programa, se n�o, acesse o Portal do Software P�blico Brasileiro no endere�o www.softwarepublico.gov.br ou escreva para a Funda��o do Software Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA 
*/

/********************************************************************************************
		
gpweb\instalacao\checar_atualizar.php		

Fun��es para verifica��o se � para instalar ou atualizar a base de dados 
																																												
********************************************************************************************/
require_once '../base.php';
require_once BASE_DIR.'/estilo/rondon/funcao_grafica.php';
require_once BASE_DIR.'/codigo/instalacao.inc.php';
require_once BASE_DIR.'/lib/adodb/adodb.inc.php';

function checarAtualizacao($config) {
	$modo = 0;
	if (is_file('../config.php')) {
		if (isset($config['hospedadoBd'])) {
			if ($resultado=checarBDexistente($config)) $modo = $resultado;
			}
		}
	return $modo;
	}

function checarBDexistente($config) {
	global $Aplic, $ADODB_FETCH_MODE;
	$Aplic = new UI_instalacao;
	$ado = @NewADOConnection($config['tipoBd'] ? $config['tipoBd'] : 'mysql');
	if (empty($ado)) return false;
	$bd = @$ado->Connect($config['hospedadoBd'], $config['usuarioBd'], $config['senhaBd']);
	
	if (!$bd) return 0;

	$existe = @$ado->SelectDB($config['nomeBd']);
	if (! $existe) return 0;

	$ADODB_FETCH_MODE = ADODB_FETCH_NUM;
	$qid = $ado->Execute('select versao_bd from versao');
	$versao_bd = $qid->fields;
	return $versao_bd[0];
	}
	

?>