<?php 
/* 
Copyright (c) 2007-2011 The web2Project Development Team <w2p-developers@web2project.net>
Copyright (c) 2003-2007 The dotProject Development Team <core-developers@dotproject.net>
Copyright [2008] -  S�rgio Fernandes Reinert de Lima
Este arquivo � parte do programa gpweb
O gpweb � um software livre; voc� pode redistribu�-lo e/ou modific�-lo dentro dos termos da Licen�a P�blica Geral GNU como publicada pela Funda��o do Software Livre (FSF); na vers�o 2 da Licen�a.
Este programa � distribu�do na esperan�a que possa ser  �til, mas SEM NENHUMA GARANTIA; sem uma garantia impl�cita de ADEQUA��O a qualquer  MERCADO ou APLICA��O EM PARTICULAR. Veja a Licen�a P�blica Geral GNU/GPL em portugu�s para maiores detalhes.
Voc� deve ter recebido uma c�pia da Licen�a P�blica Geral GNU, sob o t�tulo "licen�a GPL 2.odt", junto com este programa, se n�o, acesse o Portal do Software P�blico Brasileiro no endere�o www.softwarepublico.gov.br ou escreva para a Funda��o do Software Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA 
*/


if (!defined('BASE_DIR')) die('Voc� n�o deveria acessar este arquivo diretamente');
$celular=getParam($_REQUEST, 'celular', 0);
echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">';
echo '<head>';
echo '<title>'.(isset($config['gpweb']) ? $config['gpweb'] : 'gpweb').'</title>';
echo '<meta http-equiv="Content-Type" content="text/html;charset='.(isset($localidade_tipo_caract) ? $localidade_tipo_caract : 'iso-8859-1').'" />';
echo '<title>Login no gpweb</title>';
echo '<meta http-equiv="Pragma" content="no-cache" />';
echo '<meta name="Version" content="'.$Aplic->getVersao().'" />';
echo '<link rel="stylesheet" type="text/css" href="./estilo/rondon/estilo.css" media="all" />';
echo '<style type="text/css" media="all">@import "./estilo/rondon/estilo.css";</style>';
echo '<link rel="shortcut icon" href="./estilo/rondon/imagens/organizacao/10/favicon.ico" type="image/ico" />';
echo '<script type="text/javascript" src="'.str_replace('/codigo', "", BASE_URL).'/lib/mootools/mootools.js"></script>';
echo '</head>';
echo '<body onload="document.frmlogin.usuarioNome.focus();">';
if (!$celular) {
	echo '<br><center>'.dica('Site do '.$config['gpweb'], 'Clique para entrar no site oficial do '.$config['gpweb'].'.').'<a href="http://www.sistemagpweb.com"><img src="'.$Aplic->gpweb_logo.'" border=0 /></a>'.dicaF().'<center>';
 	echo '<br><br>';
 	}
else echo '<table width="300" cellspacing=0 cellpadding=0 align=center><tr><td></td></tr><tr><td><hr noshade size=5 style="color: #a6a6a6"></td></tr><td align=center style="font-size:35pt; padding-left: 5px; padding-right: 5px;color: #009900"><i><b>gp</b>web</td></i></tr><tr><td><hr noshade size=5 style="color: #a6a6a6"></td></tr><tr><td>&nbsp;</td></tr></table>'; 




include ('./estilo/rondon/sobrecarga.php'); 
echo '<form method="post" action="index.php" name="frmlogin">';

echo '<input type="hidden" name="login" value="'.time().'" />';
echo '<input type="hidden" name="perdeu_senha" value="0" />';
echo '<input type="hidden" name="login" value="entrar" />';
echo '<input type="hidden" name="celular" value="'.$celular.'" />';

echo '<table align="center" border=0 width="250" cellpadding=0 cellspacing=0 style="background: #f2f0ec">';
if (!$celular) echo '<tr><td colspan="2">'.estiloTopoCaixa().'</td></tr>';
else echo '<tr><td colspan=2 width="100%" style="background-color: #a6a6a6">&nbsp;</td></tr>';
echo '<tr><th colspan="2">&nbsp;</th></tr>';
echo '<tr><td align="right" nowrap="nowrap">'.dica(ucfirst($config['login']), 'Escreva o '.$config['login'].' com o qual acessa o gpweb , com no m�nimo '.config('tam_min_login').' caracteres.').'&nbsp;'.ucfirst($config['login']).':&nbsp;'.dicaF().'</td><td align="left" nowrap="nowrap"><input type="text" size="25" maxlength="255" name="usuarioNome" class="texto" /></td></tr>';
echo '<tr><td align="right" nowrap="nowrap">'.dica('Senha', 'Escreva a senha com a qual acessa o gpweb, com no m�nimo '.config('tam_min_senha').' caracteres.').'&nbsp;Senha:&nbsp;'.dicaF().'</td><td align="left" nowrap="nowrap"><input type="password" size="25" maxlength="32" name="senha" class="texto" onkeypress="return submitenter(this, event)" onunfocus="document.frmlogin.submit();" onblur="document.frmlogin.submit();" />&nbsp;</td></tr>';
echo '<tr><td colspan="2" align="center" style="background: #f2f0ec;">'.botao('entrar', 'Entrar','pressione este bot�o para acessar o gpweb, ap�s inserir o nome e a senha cadastrados.','','frmlogin.submit()').'&nbsp;</td></tr>';
if ($config['email_ativo'] && $config['militar']!=11) echo '<tr><td style="padding:2px" align="center" colspan="2" nowrap="nowrap">'.dica('Esqueceu a Senha','Clique neste link caso n�o se lembre de sua senha cadastrada para acesso ao gpweb.').'<a href="javascript: void(0);" onclick="f=document.frmlogin;f.perdeu_senha.value=1;f.submit();">Esqueci a senha</a>'.dicaF().'</td></tr>';
if ($config['ativar_criacao_externa_usuario']) echo '<tr><td style="padding:2px" colspan="2" align="center" nowrap="nowrap">'.dica('Criar Conta','Clique neste link caso n�o fa�a parte ainda d'.$config['genero_usuario'].'s '.$config['usuarios'].' registrados no gpweb.<br><br>Lembre-se de que o acesso depender� da aprova��o do cadastro.').'<a href="javascript: void(0);" onclick="javascript:window.location=\'./codigo/novo_usuario.php'.($celular ? '?celular=1' :'').'\'">Criar uma conta</a></td></tr>';
if (!$celular) echo '<tr><td colspan="2">'.estiloFundoCaixa().'</td></tr>';
else echo '<tr><td colspan=2 width="100%" style="background-color: #a6a6a6">&nbsp;</td></tr>';
echo '</table>';
if ($Aplic->getVersao()) echo '<div align="center"><span style="font-size:6pt">Vers�o '.$Aplic->getVersao().'</span></div>';
if (isset($config['exemplo'])&& $config['exemplo']){
	echo '<div align="center"><h1>Demonstra��o</h1></div>';	
	echo '<div align="center"><table cellspacing=0 cellpadding="3" border="1">';
  echo '<tr><td>Fun��o</td><td>Login</td><td>Senha</td></tr>';
  if(!isset($config['usuario_exemplo'])){
    $config['usuario_exemplo'] = array(
        array('funcao' => 'Administrador', 'login' => 'admin', 'senha' =>'123456'),
        array('funcao' => 'Usu�rio', 'login' => 's3', 'senha' => '123456'));
    }
    
  foreach($config['usuario_exemplo'] as $usuario){
    $func = isset($usuario['funcao']) ? $usuario['funcao'] : '&nbsp';
    $log = isset($usuario['login']) ? $usuario['login'] : '&nbsp';
    $sen = isset($usuario['senha']) ? $usuario['senha'] : '&nbsp';
    echo '<tr><td>'.$func.'</td><td>'.$log.'</td><td>'.$sen.'</td></tr>';
    }
  echo '</table></div>';	
	}


echo '</form>';
echo '<div align="center">';
echo '<span class="error">'.$Aplic->getMsg().'</span>';
$msg = phpversion() < '5.0' ? '<br /><span class="warning">AVISO:O gpweb n�o � suportado por esta vers�o do PHP('.phpversion().')</span>' : '';
$msg .= function_exists('mysql_pconnect') ? '' : '<br /><span class="warning">AVISO: PHP poder� n�o rodar com suporte ao MySQL. Verifique as configura��o do arquivo config.php.</span>';
echo $msg;
$Aplic->carregarRodapeJS();
echo '</div></body></html>';
?>
<SCRIPT TYPE="text/javascript">
if(parent && parent.gpwebApp){
	var gpwebApp = parent.gpwebApp;
	gpwebApp.onLogout();
}	

function submitenter(campo,e){
	var codigo;
	if (window.event) codigo = window.event.keyCode;
	else if (e) codigo = e.which;
	else return true;
	
	if (codigo == 13) {
	   campo.form.submit();
	   return false;
	   }
	else return true;
	}

</SCRIPT>

